document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("studentSignupForm");
  const successMessage = document.getElementById("successMessage");
  const errorMessage = document.getElementById("error-message");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const firstName = form.firstName.value.trim();
    const lastName = form.lastName.value.trim();
    const email = form.email.value.trim();
    const phone = form.phone.value.trim();
    const username = form.username.value.trim();
    const password = form.password.value.trim();
    const dob = form.dob.value;

    const subjectElements = document.querySelectorAll("input[name='subjects']:checked");
    const subjects = Array.from(subjectElements).map(el => el.value);

    errorMessage.style.display = "none";
    successMessage.style.display = "none";

    if (!firstName || !lastName || !email || !phone || !username || !password) {
      return showError("Please fill in all required fields.");
    }

    if (!validateEmail(email)) {
      return showError("Invalid email address.");
    }

    if (!/^\d{10}$/.test(phone) || phone[0] !== "0") {
      return showError("Phone number must be 10 digits and start with 0.");
    }

    if (username.length < 3) {
      return showError("Username must be at least 3 characters.");
    }

    if (!validatePassword(password)) {
      return showError("Password must be at least 8 characters and include uppercase, lowercase, number, and special character.");
    }

    try {
      const response = await fetch("http://127.0.0.1:3000/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: `${firstName} ${lastName}`,
          email,
          password,
          role: "student",
          phone,
          username,
          dob,
          subjects: subjects
        })
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Signup failed.");
      }

      successMessage.style.display = "block";
      successMessage.textContent = "Registration successful! 🎉 Redirecting...";

      setTimeout(() => {
        sessionStorage.setItem("signupSuccess", "You have successfully registered! 🎉");
        window.location.href = "login.html";
      }, 1500);
    } catch (err) {
      console.error("Signup error:", err);
      showError(err.message || "An error occurred.");
    }
  });

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validatePassword(password) {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/.test(password);
  }

  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = "block";
    successMessage.style.display = "none";
  }
});

