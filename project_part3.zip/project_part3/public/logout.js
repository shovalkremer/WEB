document.addEventListener("DOMContentLoaded", () => {
  const loginLink = document.getElementById("login-link");
  const logoutBtn = document.getElementById("logoutBtn");
  const welcomeText = document.getElementById("welcome-text");
  const profileLink = document.getElementById("profile-link");

  const currentUser = JSON.parse(localStorage.getItem("currentUser"));

  if (currentUser) {
    if (loginLink) loginLink.style.display = "none";

    if (profileLink) {
      profileLink.style.display = "inline-block";
      profileLink.textContent = "My Profile";
      profileLink.href = "profile.html";
    }

    if (welcomeText) {
      const fullName = currentUser.name || currentUser.username || "User";
      const firstName = fullName.split(" ")[0];
      welcomeText.textContent = `Welcome, ${firstName}!`;
      welcomeText.style.display = "inline-block";
    }

    if (logoutBtn) {
      logoutBtn.style.display = "inline-block";
      // להסיר מאזין קודם אם קיים
      logoutBtn.onclick = null;
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault();
        localStorage.removeItem("currentUser");
        localStorage.removeItem("token");  // להסיר טוקן בלוגאוט
        alert("You have successfully logged out!");
        window.location.href = "home.html";
      });
    }
  } else {
    if (loginLink) loginLink.style.display = "inline-block";
    if (logoutBtn) logoutBtn.style.display = "none";
    if (welcomeText) welcomeText.style.display = "none";
    if (profileLink) profileLink.style.display = "none";
  }
});

