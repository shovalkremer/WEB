// availability.js – full script for managing weekly availability

document.addEventListener("DOMContentLoaded", () => {
  generateTimeOptions();
  document.getElementById("addSlotBtn").addEventListener("click", addSlot);
  document.getElementById("saveBtn").addEventListener("click", saveSlotsToServer);

  // Load existing availability from server on page load
  loadAvailabilityFromServer();
});

const slots = [];

/**
 * Generate time options from 07:00 to 23:30 in 30-min intervals
 */
function generateTimeOptions() {
  const timeSelect = document.getElementById("time");
  const startHour = 7;
  const endHour = 23.5;

  for (let h = startHour; h <= endHour; h += 0.5) {
    const hour = Math.floor(h);
    const minutes = h % 1 === 0 ? "00" : "30";
    const value = `${hour.toString().padStart(2, '0')}:${minutes}`;
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    timeSelect.appendChild(option);
  }
}

/**
 * Calculate the next date for a given weekday (Sunday–Saturday)
 */
function getNextDateForDay(dayName) {
  const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const today = new Date();
  const todayIndex = today.getDay();
  const targetIndex = daysOfWeek.indexOf(dayName);

  let diff = targetIndex - todayIndex;
  if (diff < 0) diff += 7;

  const resultDate = new Date(today);
  resultDate.setDate(today.getDate() + diff);

  return resultDate.toISOString().split("T")[0]; // YYYY-MM-DD
}

/**
 * Add a new availability slot
 */
function addSlot() {
  const day = document.getElementById("day").value;
  const time = document.getElementById("time").value;
  const type = document.getElementById("type").value;

  if (!day || !time || !type) {
    alert("Please fill all fields");
    return;
  }

  // Prevent duplicate slot (same day, time and type)
  const alreadyExists = slots.some(s => s.day === day && s.time === time && s.type === type);
  if (alreadyExists) {
    alert("This slot already exists!");
    return;
  }

  const date = getNextDateForDay(day);
  const slot = { day, date, time, type };
  slots.push(slot);
  updateLocalSlotsView();
}

/**
 * Update the view showing slots that are about to be saved
 */
function updateLocalSlotsView() {
  const container = document.getElementById("slotsContainer");
  container.innerHTML = "";

  slots.forEach((s, i) => {
    const div = document.createElement("div");
    div.className = "availability-slot";
    div.innerHTML = `
      <span>📅 ${s.day} (${s.date}), 🕒 ${s.time} – 🧑‍🏫 ${s.type}</span>
      <button type="button" onclick="removeSlot(${i})">Remove</button>
    `;
    container.appendChild(div);
  });
}

/**
 * Remove a slot by index
 */
function removeSlot(index) {
  slots.splice(index, 1);
  updateLocalSlotsView();
}

/**
 * Send the slots to the server to be saved
 */
async function saveSlotsToServer() {
  if (slots.length === 0) {
    alert("Please add at least one slot");
    return;
  }

  const response = await fetch("/save-availability", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({ slots: JSON.stringify(slots) }),
    credentials: "include" // send cookies
  });

  const text = await response.text();
  if (response.ok) {
    alert("Availability saved successfully!");
    slots.length = 0; // clear local array
    updateLocalSlotsView();
    loadAvailabilityFromServer(); // refresh from DB
  } else {
    alert("Error saving availability: " + text);
  }
}

/**
 * Fetch and display all saved slots from the server
 */
async function loadAvailabilityFromServer() {
  const response = await fetch("/my-availability", {
    method: "GET",
    credentials: "include"
  });

  if (!response.ok) {
    console.error("Failed to fetch availability");
    return;
  }

  const serverSlots = await response.json();
  const container = document.getElementById("slotsContainer");
  container.innerHTML = "";

    serverSlots.forEach((s) => {
    const dateStr = new Date(s.date).toLocaleDateString("en-GB"); 
    const div = document.createElement("div");
    div.className = "availability-slot";
    div.innerHTML = `
        <span>📅 ${s.day} (${dateStr}), 🕒 ${s.time} – 🧑‍🏫 ${s.type}</span>
        <button type="button" onclick="deleteSlot(${s.id})">❌ Remove</button>
    `;
    container.appendChild(div);
    });

}

async function deleteSlot(id) {
  const confirmDelete = confirm("Are you sure you want to delete this slot?");
  if (!confirmDelete) return;

  const response = await fetch(`/availability/${id}`, {
    method: "DELETE",
    credentials: "include"
  });

  if (response.ok) {
    alert("Slot deleted!");
    loadAvailabilityFromServer();
  } else {
    alert("Failed to delete slot");
  }
}
