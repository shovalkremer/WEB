document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const username = params.get("username");

  const profileDiv = document.querySelector(".tutorprofile");

  if (!username) {
    profileDiv.innerHTML = "<h2>Teacher not found</h2>";
    return;
  }

  try {
    const token = localStorage.getItem("token");
    if (!token) {
      window.location.href = "login.html";
      return;
    }

    const res = await fetch(`http://localhost:3000/auth/tutors/${username}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok) throw new Error("Tutor not found");
    const tutor = await res.json();

    // 🟩 תמונת פרופיל
    const imgSrc = tutor.profilePhotoName
      ? `http://localhost:3000/uploads/${tutor.profilePhotoName}`
      : "images/default.png";
    const img = document.getElementById("tutorImage");
    img.src = imgSrc;
    img.alt = `${tutor.name} profile photo`;

    // 🟩 פרטים בסיסיים
    document.getElementById("tutorName").textContent = tutor.name || "Not specified";
    document.getElementById("tutorSubject").textContent = 
      Array.isArray(tutor.subjects)
        ? tutor.subjects.join(", ")
        : (tutor.subjects || "Not specified");

    document.getElementById("tutorRate").textContent = tutor.pricePerHour || "Not specified";
    document.getElementById("tutorFormat").textContent = tutor.teachingMethod || "Not specified";
    document.getElementById("tutorLocation").textContent = tutor.area || "Not specified";
    document.getElementById("tutorBio").textContent = tutor.bio || "Not specified";
    document.getElementById("tutorExperience").textContent = tutor.background || "Not specified";

    // 🟩 זמינות (availability) – אם היא מחרוזת JSON, נפענח אותה
    const availability = typeof tutor.availability === "string"
      ? JSON.parse(tutor.availability)
      : (tutor.availability || []);
    document.getElementById("tutorAvailability").textContent =
      availability.length > 0 ? availability.join(", ") : "Not specified";

    // 🟩 טלפון
    document.getElementById("tutorPhone").textContent = tutor.phone || "Not specified";

    // 🟩 שיעורים פנויים
    const lessonSlotsDiv = document.getElementById("lessonSlots");
    lessonSlotsDiv.innerHTML = ""; // נקה תוכן קודם
    if (Array.isArray(tutor.lessonSlots) && tutor.lessonSlots.length > 0) {
      tutor.lessonSlots.forEach(slot => {
        const slotDiv = document.createElement("div");
        slotDiv.className = "lesson-slot";
        slotDiv.innerHTML = `
          <span class="slot-date">${new Date(slot.date).toLocaleString("he-IL")}</span>
          <span class="slot-type">${slot.type}</span>
          <span class="slot-price">₪${slot.price}</span>
          <button class="book-btn">Book Lesson</button>
        `;
        lessonSlotsDiv.appendChild(slotDiv);
      });
    } else {
      lessonSlotsDiv.innerHTML = "<p>No lessons available</p>";
    }

    // 🟩 ביקורות
    const reviewsDiv = document.getElementById("tutorReviews");
    reviewsDiv.innerHTML = ""; // נקה תוכן קודם
    if (Array.isArray(tutor.reviews) && tutor.reviews.length > 0) {
      tutor.reviews.forEach(review => {
        const reviewDiv = document.createElement("div");
        reviewDiv.className = "review";
        reviewDiv.innerHTML = `
          <div class="review-header">
            <span class="review-stars">${review.stars || "★★★★★"}</span>
            <span class="review-name">${review.name}, ${review.date}</span>
          </div>
          <p>"${review.text}"</p>
        `;
        reviewsDiv.appendChild(reviewDiv);
      });
    } else {
      reviewsDiv.innerHTML = "<p>No reviews yet</p>";
    }

  } catch (err) {
    console.error("Error loading tutor:", err);
    profileDiv.innerHTML = "<h2>Teacher does not exist in the system.</h2>";
  }
});
