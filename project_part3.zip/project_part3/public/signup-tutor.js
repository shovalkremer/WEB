document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("tutorSignupForm");
  const successMessage = document.getElementById("successMessage");
  const errorMessage = document.getElementById("error-message");
  const calendarEl = document.getElementById("calendar");
  const resetBtn = document.getElementById("resetButton");

  let availability = [];

  // Initialize calendar
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "timeGridWeek",
    selectable: true,
    editable: true,
    allDaySlot: false,
    slotMinTime: "08:00:00",
    slotMaxTime: "22:00:00",
    events: [],
    select: (info) => {
      const event = { start: info.startStr, end: info.endStr };
      availability.push(event);
      calendar.addEvent(event);
    },
    eventClick: (info) => {
      availability = availability.filter(
        (ev) =>
          ev.start !== info.event.start.toISOString() ||
          ev.end !== info.event.end.toISOString()
      );
      info.event.remove();
    },
  });

  calendar.render();

  resetBtn.addEventListener("click", () => {
    availability = [];
    calendar.getEvents().forEach((event) => event.remove());
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearMessages();

    const formData = new FormData(form);

    const firstName = formData.get("firstName")?.trim();
    const lastName = formData.get("lastName")?.trim();
    const email = formData.get("email")?.trim();
    const phone = formData.get("phone")?.trim();
    const username = formData.get("username")?.trim();
    const password = formData.get("password")?.trim();
    const price = formData.get("price")?.trim();
    const subjects = formData.getAll("subjects[]");
    const profilePhoto = formData.get("profilePhoto");

    // Basic validation
    if (
      !firstName ||
      !lastName ||
      !email ||
      !phone ||
      !username ||
      !password ||
      !price
    ) {
      return showError("Please fill in all required fields.");
    }
    if (!validateEmail(email)) return showError("Invalid email address.");
    if (!validatePhone(phone)) return showError("Invalid phone number.");
    if (username.length < 3)
      return showError("Username must be at least 3 characters.");
    if (!validatePassword(password))
      return showError(
        "Password must include uppercase, lowercase, number, and special character."
      );
    if (subjects.length === 0)
      return showError("Please select at least one subject.");
    if (isNaN(price) || Number(price) <= 0)
      return showError("Price must be a positive number.");
    if (!profilePhoto || profilePhoto.size === 0)
      return showError("Please upload a profile photo.");
    if (!profilePhoto.type.startsWith("image/"))
      return showError("Uploaded file must be an image.");

    try {
      const extension = profilePhoto.name.split(".").pop();
      const newFileName = `${firstName}.${extension}`;
      const renamedFile = new File([profilePhoto], newFileName, {
        type: profilePhoto.type,
      });

      const newFormData = new FormData();
      newFormData.append("name", `${firstName} ${lastName}`);
      newFormData.append("email", email);
      newFormData.append("phone", phone);
      newFormData.append("username", username);
      newFormData.append("password", password);
      newFormData.append("dob", formData.get("dob"));
      newFormData.append("role", "tutor");
      newFormData.append("pricePerHour", Number(price));
      newFormData.append("teachingMethod", formData.get("teachingMethod"));
      newFormData.append("area", formData.get("area"));
      newFormData.append("background", formData.get("background")?.trim() || "");
      newFormData.append("bio", formData.get("bio")?.trim() || "");
      newFormData.append("profilePhoto", renamedFile);

      subjects.forEach((subject) =>
        newFormData.append("subjects", subject)
      );
      availability.forEach((slot) =>
        newFormData.append("availability", JSON.stringify(slot))
      );

      const response = await fetch("http://localhost:3000/auth/tutors/signup", {
        method: "POST",
        body: newFormData,
      });

      const result = await response.json();

      if (response.ok) {
        successMessage.style.display = "block";
        successMessage.textContent =
          "Registration successful! Redirecting to login...";
        sessionStorage.setItem(
          "signupSuccess",
          "Registration successful! You can now log in."
        );
        setTimeout(() => {
          window.location.href = "login.html";
        }, 2000);
      } else {
        showError(result.message || "Signup failed.");
      }
    } catch (err) {
      console.error("Error during signup fetch or processing:", err);
      showError("Server error. Please try again later.");
    }
  });

  // --- פונקציות עזר ---

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  function validatePhone(phone) {
    const re = /^0\d{9}$/;
    return re.test(phone);
  }

  function validatePassword(password) {
    const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    return re.test(password);
  }

  function showError(message) {
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
    successMessage.style.display = "none";
  }

  function clearMessages() {
    errorMessage.style.display = "none";
    errorMessage.textContent = "";
    successMessage.style.display = "none";
    successMessage.textContent = "";
  }
});


