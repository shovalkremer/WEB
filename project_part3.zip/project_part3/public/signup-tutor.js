document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("tutorSignupForm");
  const successMessage = document.getElementById("successMessage");
  const errorMessage = document.getElementById("error-message");
  const calendarEl = document.getElementById("calendar");
  const resetBtn = document.getElementById("resetButton");

  let availability = [];

  // Initialize calendar
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "timeGridWeek",
    selectable: true,
    editable: true,
    allDaySlot: false,
    slotMinTime: "08:00:00",
    slotMaxTime: "22:00:00",
    events: [],
    select: (info) => {
      const event = {
        start: info.startStr,
        end: info.endStr
      };
      availability.push(event);
      calendar.addEvent(event);
    },
    eventClick: (info) => {
      availability = availability.filter(ev =>
        ev.start !== info.event.start.toISOString() || ev.end !== info.event.end.toISOString()
      );
      info.event.remove();
    }
  });

  calendar.render();

  resetBtn.addEventListener("click", () => {
    availability = [];
    calendar.getEvents().forEach(event => event.remove());
  });

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    clearMessages();

    const formData = new FormData(form);
    const firstName = formData.get("firstName")?.trim();
    const lastName = formData.get("lastName")?.trim();
    const email = formData.get("email")?.trim();
    const phone = formData.get("phone")?.trim();
    const username = formData.get("username")?.trim();
    const password = formData.get("password")?.trim();
    const price = formData.get("price")?.trim();
    const subjects = formData.getAll("subjects[]");
    const profilePhoto = formData.get("profilePhoto");

    // Basic validation
    if (!firstName || !lastName || !email || !phone || !username || !password || !price) {
      return showError("Please fill in all required fields.");
    }
    if (!validateEmail(email)) return showError("Invalid email address.");
    if (!validatePhone(phone)) return showError("Invalid phone number.");
    if (username.length < 3) return showError("Username must be at least 3 characters.");
    if (!validatePassword(password)) return showError("Password must include uppercase, lowercase, number, and special character.");
    if (subjects.length === 0) return showError("Please select at least one subject.");
    if (isNaN(price) || Number(price) <= 0) return showError("Price must be a positive number.");
    if (!profilePhoto || profilePhoto.size === 0) return showError("Please upload a profile photo.");
    if (!profilePhoto.type.startsWith("image/")) return showError("Uploaded file must be an image.");

    try {
      const profilePhotoData = await fileToBase64(profilePhoto);

      const newTutor = {
        name: `${firstName} ${lastName}`,
        email,
        phone,
        username,
        password,
        dob: formData.get("dob"),
        role: "tutor",
        subjects,
        profilePhotoName: profilePhoto.name,
        profilePhotoData,
        background: formData.get("background")?.trim() || "",
        bio: formData.get("bio")?.trim() || "",
        pricePerHour: Number(price),
        teachingMethod: formData.get("teachingMethod"),
        area: formData.get("area"),
        availability
      };

      console.log("Sending signup data:", newTutor);

      const response = await fetch("http://localhost:3000/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTutor)
      });

      if (response.ok) {
        const result = await response.json();
        localStorage.setItem("token", result.token);
        localStorage.setItem("username", result.username);

        successMessage.style.display = "block";
        successMessage.textContent = "Registration successful! Redirecting to login...";
        sessionStorage.setItem("signupSuccess", "Registration successful! You can now log in.");
        setTimeout(() => {
          window.location.href = "login.html";
        }, 2000);
      } else {
        // נסה לקרוא את השגיאה מהשרת
        let errorText;
        try {
          errorText = await response.text();
          if (!errorText) errorText = `Error: ${response.status} ${response.statusText}`;
        } catch {
          errorText = `Error: ${response.status} ${response.statusText}`;
        }
        console.error("Signup failed:", errorText);
        showError(errorText);
      }
    } catch (err) {
      console.error("Error during signup fetch or processing:", err);
      showError("Server error. Please try again later.");
    }
  });

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  function validatePhone(phone) {
    const re = /^0\d{9}$/;
    return re.test(phone);
  }

  function validatePassword(password) {
    // לפחות 8 תווים, אות גדולה, אות קטנה, ספרה וסימן מיוחד
    const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    return re.test(password);
  }

  function showError(message) {
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
    successMessage.style.display = "none";
  }

  function clearMessages() {
    errorMessage.style.display = "none";
    errorMessage.textContent = "";
    successMessage.style.display = "none";
    successMessage.textContent = "";
  }

  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Failed to read file."));
      reader.readAsDataURL(file);
    });
  }
});


