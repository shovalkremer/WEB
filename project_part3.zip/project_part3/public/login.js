document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const errorMessage = document.getElementById("error-message");
  const logoutBtn = document.getElementById("logoutBtn");
  const loginLink = document.getElementById("login-link");

  // Handle login form submission
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const email = document.getElementById("loginEmail").value.trim();
      const password = document.getElementById("loginPassword").value;

      fetch("http://127.0.0.1:3000/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
      })
        .then(async (res) => {
          if (!res.ok) {
            const text = await res.text();
            throw new Error(text || "Login failed");
          }
          return res.json();
        })
        .then((data) => {
          // Save the user in localStorage just to keep session
          localStorage.setItem("currentUser", JSON.stringify({
            ...data.user,
            token: data.token
          }));

          window.location.href = "home.html";
          sessionStorage.setItem("loggedInUser", JSON.stringify(data.user));
        })
        .catch((err) => {
          console.error("Login error:", err);
          errorMessage.style.display = "block";
          errorMessage.textContent = err.message || "Invalid credentials.";
        });
    });
  }

  // Handle logout
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("currentUser");
      sessionStorage.removeItem("loggedInUser");
      alert("You have successfully logged out!");
      window.location.href = "login.html";
    });
  }

  // Update header for logged-in user
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  if (currentUser) {
    if (loginLink) loginLink.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "inline-block";
  }

  const successMsg = sessionStorage.getItem("signupSuccess");
  if (successMsg) {
    alert(successMsg);
    sessionStorage.removeItem("signupSuccess");
  }
});
