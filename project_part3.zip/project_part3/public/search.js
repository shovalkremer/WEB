document.addEventListener("DOMContentLoaded", () => {
  const resultsContainer = document.getElementById("resultsContainer");
  const resultsSection = document.getElementById("resultsSection");
  const noResultsMessage = document.getElementById("noResultsMessage");
  const form = document.getElementById("searchForm");

  const API_URL = "http://localhost:3000"; 

  const getTutorsFromServer = async () => {
    try {
      const res = await fetch(`${API_URL}/auth/tutors`);
      if (!res.ok) throw new Error("Failed to fetch tutors");
      const tutors = await res.json();

      return tutors.map(t => ({
        ...t,
        subjects: t.subjects ? t.subjects.split(",").map(s => s.trim()) : [],
        availability: t.availability ? JSON.parse(t.availability) : []
      }));
    } catch (err) {
      console.error("Error fetching tutors:", err);
      return [];
    }
  };

  const createTutorCard = (tutor) => {
    const card = document.createElement("div");
    card.className = "tutor-card";

    const imgSrc = tutor.profilePhotoName
      ? `${API_URL}/uploads/${tutor.profilePhotoName}`
      : "images/default.png";

    card.innerHTML = `
      <img src="${imgSrc}" alt="Profile Photo" />
      <h3>${tutor.name}</h3>
      <p><strong>Subjects:</strong> ${tutor.subjects.join(', ')}</p>
      <p><strong>Location:</strong> ${tutor.area || "N/A"}</p>
      <p><strong>Method:</strong> ${tutor.teachingMethod || "N/A"}</p>
      <p><strong>Price:</strong> ₪${tutor.pricePerHour ?? "indefinite"}</p>
      <p><strong>Bio:</strong> ${tutor.bio || "No bio available."}</p>
      <button onclick="location.href='teacher-profile.html?username=${encodeURIComponent(tutor.username)}'">View Profile</button>
    `;
    return card;
  };

  const displayTutors = (tutors) => {
    resultsContainer.innerHTML = "";
    if (!Array.isArray(tutors) || tutors.length === 0) {
      noResultsMessage.style.display = "block";
      resultsSection.style.display = "block";
      return;
    }

    noResultsMessage.style.display = "none";
    resultsSection.style.display = "block";

    tutors.forEach(tutor => {
      const card = createTutorCard(tutor);
      resultsContainer.appendChild(card);
    });
  };

  const filterTutors = (tutors, filters) => {
    let filtered = tutors;

    if (filters.subject) {
      const subjectLower = filters.subject.toLowerCase();
      filtered = filtered.filter(t =>
        t.subjects.some(s => s.toLowerCase() === subjectLower)
      );
    }

    if (filters.location) {
      filtered = filtered.filter(t =>
        (t.area || "").toLowerCase().includes(filters.location.toLowerCase())
      );
    }

    if (filters.price && !isNaN(filters.price)) {
      filtered = filtered.filter(t =>
        Number(t.pricePerHour) <= Number(filters.price)
      );
    }

    if (filters.lessonType) {
      filtered = filtered.filter(t =>
        t.teachingMethod === filters.lessonType
      );
    }

    if (filters.rating && !isNaN(filters.rating)) {
      filtered = filtered.filter(t =>
        Number(t.rating) >= Number(filters.rating)
      );
    }

    displayTutors(filtered);
  };

  let allTutors = [];

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const filters = {
      subject: document.getElementById("subject").value.trim(),
      location: document.getElementById("location").value.trim(),
      price: document.getElementById("price").value.trim(),
      lessonType: document.getElementById("lessonType").value.trim(),
      rating: document.getElementById("rating").value.trim()
    };
    filterTutors(allTutors, filters);
  });

  // Load all tutors on page load
  getTutorsFromServer().then(tutors => {
    allTutors = tutors;
    displayTutors(allTutors);
  });
});
