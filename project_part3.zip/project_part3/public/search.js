document.addEventListener("DOMContentLoaded", () => {
  const resultsContainer = document.getElementById("resultsContainer");
  const resultsSection = document.getElementById("resultsSection");
  const noResultsMessage = document.getElementById("noResultsMessage");
  const form = document.getElementById("searchForm");

  const API_URL = "http://localhost:3000";

  const safeParse = (field) => {
    if (Array.isArray(field)) return field;
    try {
      return JSON.parse(field);
    } catch {
      return [];
    }
  };

  // === בקשת מורים מהשרת לפי פילטרים ===
  const getTutorsFromServer = async (filters = {}) => {
    try {
      const queryParams = new URLSearchParams();

      if (filters.subjects) queryParams.append("subjects", filters.subjects);
      if (filters.area) queryParams.append("area", filters.area);
      if (filters.maxPrice) queryParams.append("maxPrice", filters.maxPrice);
      if (filters.teachingMethod) queryParams.append("teachingMethod", filters.teachingMethod);

      const res = await fetch(`${API_URL}/users/search?${queryParams.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch tutors");

      const tutors = await res.json();

      return tutors.map(t => ({
        ...t,
        subjects: safeParse(t.subjects),
        availability: safeParse(t.availability),
        lessonSlots: safeParse(t.lessonSlots),
        reviews: safeParse(t.reviews),
      }));
    } catch (err) {
      console.error("Error fetching tutors:", err);
      return [];
    }
  };

  // === יצירת כרטיס מורה להצגה ===
  const createTutorCard = (tutor) => {
    const card = document.createElement("div");
    card.className = "tutor-card";

    const imgSrc = tutor.profilePhotoName
      ? `${API_URL}/uploads/${tutor.profilePhotoName}`
      : "images/default.png";

    card.innerHTML = `
      <img src="${imgSrc}" alt="Profile Photo" />
      <h3>${tutor.name}</h3>
      <p><strong>Subjects:</strong> ${Array.isArray(tutor.subjects) ? tutor.subjects.join(", ") : ""}</p>
      <p><strong>Location:</strong> ${tutor.area || "N/A"}</p>
      <p><strong>Method:</strong> ${tutor.teachingMethod || "N/A"}</p>
      <p><strong>Price:</strong> ₪${tutor.pricePerHour ?? "indefinite"}</p>
      <p><strong>Bio:</strong> ${tutor.bio || "No bio available."}</p>
      <button onclick="location.href='teacher-profile.html?username=${encodeURIComponent(tutor.username)}'">View Profile</button>
    `;
    return card;
  };

  // === הצגת המורים בדף ===
  const displayTutors = (tutors) => {
    resultsContainer.innerHTML = "";
    if (!Array.isArray(tutors) || tutors.length === 0) {
      noResultsMessage.style.display = "block";
      resultsSection.style.display = "block";
      return;
    }

    noResultsMessage.style.display = "none";
    resultsSection.style.display = "block";

    tutors.forEach(tutor => {
      const card = createTutorCard(tutor);
      resultsContainer.appendChild(card);
    });
  };

  // === שליחת הטופס והבאת תוצאות מהשרת ===
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const filters = {
      subjects: document.getElementById("subject").value.trim(),
      area: document.getElementById("location").value.trim(),
      maxPrice: document.getElementById("price").value.trim(),
      teachingMethod: document.getElementById("lessonType").value.trim()
    };

    const filteredTutors = await getTutorsFromServer(filters);
    displayTutors(filteredTutors);
  });

  // === טעינה ראשונית של כל המורים ללא סינון ===
  getTutorsFromServer().then(displayTutors);
});
