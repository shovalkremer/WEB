document.addEventListener("DOMContentLoaded", () => {
  // בדיקה אם המשתמש מחובר
  const path = window.location.pathname;
  const isHomePage = path.includes("home.html") || path === "/" || path === "/index.html";

  const loggedInUser = JSON.parse(localStorage.getItem("currentUser"));
  if (loggedInUser && isHomePage) {
    // הפניה לדשבורד
    window.location.href = "dashboard.html";
    return;  // עוצר את שאר הקוד שלא ירוץ אם מחובר
  }

  // ---------- FORM VALIDATION + SUBMIT TO SERVER ----------
  const form = document.querySelector("form");
  if (form) {
    const submitButton = form.querySelector("button[type='submit']");
    if (submitButton) {
      submitButton.addEventListener("click", async (event) => {
        event.preventDefault();

        const firstName = form.querySelector("#firstName")?.value.trim() || "";
        const lastName = form.querySelector("#lastName")?.value.trim() || "";
        const email = form.querySelector("#email").value.trim();
        const phone = form.querySelector("#phone").value.trim();
        const dob = form.querySelector("#dob").value.trim();
        const password = form.querySelector("#password").value;

        if (!validateEmail(email)) {
          alert("Invalid email!");
          return;
        }

        if (!validatePhone(phone)) {
          alert("Invalid phone number! Make sure it starts with 0 and has 10 digits.");
          return;
        }

        if (!validateDOB(dob)) {
          alert("Invalid date of birth! You must be at least 18 years old.");
          return;
        }

        const fullName = `${firstName} ${lastName}`.trim();

        const formData = {
          name: fullName,
          email,
          password,
          role: form.querySelector('input[name="role"]:checked')?.value || "student",
          phone,
          dob
        };

        try {
          const response = await fetch('/auth/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
          });

          if (!response.ok) {
            const errorMsg = await response.text();
            alert(`Registration failed: ${errorMsg}`);
            return;
          }

          const data = await response.json();
          alert("Registration successful! Your user ID is: " + data.id);

          window.location.href = 'login.html';

        } catch (error) {
          console.error('Error during registration:', error);
          alert('Server error. Please try again later.');
        }
      });
    }
  }

  // ---------- LOGIN/LOGOUT UI HANDLING ----------

  const loginLink = document.getElementById("login-link");
  const logoutBtn = document.getElementById("logoutBtn");
  const welcomeText = document.getElementById("welcome-text");
  const profileLink = document.getElementById("profile-link");

  // כאן לא נרצה לשנות כי כבר יש ניתוב לעיל אם מחובר
  // אך אפשר להשאיר UI עדכני אם כבר ב-home ללא הפניה

  if (loggedInUser) {
    if (loginLink) loginLink.style.display = "none";

    if (profileLink) {
      profileLink.style.display = "inline-block";
      profileLink.textContent = "My Profile";
      profileLink.href = "profile.html";
    }

    if (logoutBtn) {
      logoutBtn.style.display = "inline-block";
      logoutBtn.textContent = "Logout";

      if (typeof styleLogoutButton === "function") {
        styleLogoutButton(logoutBtn);
      }

      logoutBtn.onclick = (e) => {
        e.preventDefault();
        localStorage.removeItem("currentUser");
        sessionStorage.removeItem("signupSuccess");
        alert("You have been logged out successfully!");
        window.location.href = "home.html";
      };
    }

    if (welcomeText) {
      const fullName = loggedInUser.name || loggedInUser.username || "User";
      const firstName = fullName.split(" ")[0];
      welcomeText.textContent = `Welcome, ${firstName}!`;
      welcomeText.style.display = "inline-block";
    }
  } else {
    if (loginLink) loginLink.style.display = "inline-block";
    if (profileLink) profileLink.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "none";
    if (welcomeText) welcomeText.style.display = "none";
  }

  // ---------- VALIDATION HELPERS ----------

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validatePhone(phone) {
    return /^\d{10}$/.test(phone) && phone.startsWith("0");
  }

  function validateDOB(dob) {
    const birthDate = new Date(dob);
    const ageDifMs = Date.now() - birthDate.getTime();
    const ageDate = new Date(ageDifMs);
    const age = Math.abs(ageDate.getUTCFullYear() - 1970);
    return age >= 18;
  }
});

