document.addEventListener("DOMContentLoaded", async function () {

  // ====== שליפת המשתמש המחובר מה-localStorage ======
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));

  if (!currentUser || (!currentUser.username && !currentUser.name)) {
    alert("You are not logged in.");
    window.location.href = "login.html";
    return;
  }

  const username = currentUser.username || currentUser.name;

  try {
    // ====== שליפת נתוני המשתמש מהשרת ======
    const res = await fetch(`http://localhost:3000/auth/user/${username}`, {
      headers: {
        'Authorization': `Bearer ${currentUser.token}`
      }
    });

    if (!res.ok) throw new Error("User not found");

    const user = await res.json();

    // ====== מילוי פרטים בסיסיים ======
    const fullName = user.name || `${user.firstName || ''} ${user.lastName || ''}`.trim();
    document.getElementById("fullName").textContent = fullName;
    document.getElementById("email").textContent = user.email || '';
    document.getElementById("username").textContent = user.username || '';
    document.getElementById("phone").textContent = user.phone || '';

    // ====== אם המשתמש הוא מורה, מציגים את כל שדות ההוראה ======
    console.log("User from server:", user);
    if (user.role === "tutor") {
      let subjects = [];
      try {
        subjects = typeof user.subjects === 'string' ? JSON.parse(user.subjects) : user.subjects;
      } catch (e) {
        console.warn("Failed to parse subjects", e);
      }
      document.getElementById("subjects").textContent = (subjects || []).join(', ');

      document.getElementById("method").textContent = user.teachingMethod || '';
      document.getElementById("price").textContent = user.pricePerHour || '';
      document.getElementById("area").textContent = user.area || '';
      document.getElementById("background").textContent = user.background || '';
      document.getElementById("bio").textContent = user.bio || '';

      // 🟩 תמונת פרופיל
      const img = document.getElementById("profilePhoto");
      if (img) {
      const profileImg = user.profilePhotoName
        ? `http://localhost:3000/uploads/${user.profilePhotoName}`
        : "images/default.png";
      img.src = profileImg;
      img.alt = `${user.name || user.firstName || ''} profilePhoto`;
    }

    } 

    
    // ====== אם המשתמש הוא תלמיד, מסתירים שדות שאינם רלוונטיים ======
    else {
      document.querySelectorAll(".tutor-only").forEach(el => {
        el.style.display = "none";
      });
      const profileImg = document.querySelector(".profile-img");
      if (profileImg) profileImg.style.display = "none";
    }

  } catch (err) {
    console.error(err);
    alert("Failed to load profile data.");
  }
});
