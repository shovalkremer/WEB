require('dotenv').config();
const mysql = require('mysql2/promise');

// יצירת connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'my_project',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});



// פונקציות כלליות להרצת שאילתות
async function runQuery(sql, params = []) {
  const [result] = await pool.execute(sql, params);
  return result;
}

async function getQuery(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows[0];
}

async function allQuery(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

// פונקציה לסידור המרה של שדות JSON בקבלת רשומה בודדת
function parseJsonFields(user) {
  if (!user) return null;
  try { if (user.subjects) user.subjects = JSON.parse(user.subjects); } catch { user.subjects = null; }
  try { if (user.availability) user.availability = JSON.parse(user.availability); } catch { user.availability = null; }
  try { if (user.lessonSlots) user.lessonSlots = JSON.parse(user.lessonSlots); } catch { user.lessonSlots = null; }
  try { if (user.reviews) user.reviews = JSON.parse(user.reviews); } catch { user.reviews = null; }
  return user;
}

// פונקציה להמרת שדות JSON לפני שמירה במסד
function stringifyJsonFields(user) {
  const copy = { ...user };
  if (copy.subjects && typeof copy.subjects !== 'string') copy.subjects = JSON.stringify(copy.subjects);
  if (copy.availability && typeof copy.availability !== 'string') copy.availability = JSON.stringify(copy.availability);
  if (copy.lessonSlots && typeof copy.lessonSlots !== 'string') copy.lessonSlots = JSON.stringify(copy.lessonSlots);
  if (copy.reviews && typeof copy.reviews !== 'string') copy.reviews = JSON.stringify(copy.reviews);
  return copy;
}

// ===== API ===== //

module.exports = {

  // שליפות
  async getAllUsers() {
    const rows = await allQuery('SELECT * FROM users');
    return rows.map(parseJsonFields);
  },

  async getAllTutors() {
    const rows = await allQuery("SELECT * FROM users WHERE role = 'tutor'");
    return rows.map(parseJsonFields);
  },

  async getAllStudents() {
    const rows = await allQuery("SELECT * FROM users WHERE role = 'student'");
    return rows.map(parseJsonFields);
  },

  async getUserByEmail(email) {
    const row = await getQuery('SELECT * FROM users WHERE email = ?', [email]);
    return parseJsonFields(row);
  },

  async getUserById(id) {
    const row = await getQuery('SELECT * FROM users WHERE id = ?', [id]);
    return parseJsonFields(row);
  },

  async getUserByUsername(username) {
    const row = await getQuery('SELECT * FROM users WHERE username = ?', [username]);
    return parseJsonFields(row);
  },

  async getUsersByRole(role) {
    const rows = await allQuery("SELECT * FROM users WHERE role = ?", [role]);
    return rows.map(parseJsonFields);
  },

  // יצירה
  async createUser(user) {
    const u = stringifyJsonFields(user);

    return runQuery(
      `INSERT INTO users (
        name, email, password, role, phone, username, dob, subjects, 
        profilePhotoName, profilePhotoData, background, bio, pricePerHour, 
        teachingMethod, area, availability, lessonSlots, reviews
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        u.name,
        u.email,
        u.password,
        u.role,
        u.phone || null,
        u.username || null,
        u.dob || null,
        u.subjects || null,
        u.profilePhotoName || null,
        u.profilePhotoData || null,
        u.background || null,
        u.bio || null,
        u.pricePerHour || null,
        u.teachingMethod || null,
        u.area || null,
        u.availability || null,
        u.lessonSlots || null,
        u.reviews || null
      ]
    );
  },

  // עדכונים
  async updateUserById(id, updates) {
    const u = stringifyJsonFields(updates);
    const fields = Object.keys(u);
    const values = Object.values(u);
    const setClause = fields.map((field) => `${field} = ?`).join(', ');
    return runQuery(`UPDATE users SET ${setClause} WHERE id = ?`, [...values, id]);
  },

  async updateUserByEmail(email, updates) {
    const u = stringifyJsonFields(updates);
    const fields = Object.keys(u);
    const values = Object.values(u);
    const setClause = fields.map((field) => `${field} = ?`).join(', ');
    return runQuery(`UPDATE users SET ${setClause} WHERE email = ?`, [...values, email]);
  },

  // מחיקה
  async deleteUserByEmail(email) {
    return runQuery('DELETE FROM users WHERE email = ?', [email]);
  },

  // חיפוש מורים עם פילטרים
  async searchTutors({ subjects, area, maxPrice }) {
    let sql = `SELECT * FROM users WHERE role = 'tutor'`;
    const params = [];

    if (subjects) {
      sql += ` AND subjects LIKE ?`;
      params.push(`%${subjects}%`);
    }

    if (area) {
      sql += ` AND area LIKE ?`;
      params.push(`%${area}%`);
    }

    if (maxPrice !== null && maxPrice !== undefined) {
      sql += ` AND pricePerHour <= ?`;
      params.push(maxPrice);
    }

    const rows = await allQuery(sql, params);
    return rows.map(parseJsonFields);
  }
};

module.exports = { pool };










