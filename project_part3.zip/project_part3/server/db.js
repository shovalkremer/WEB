require('dotenv').config();
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// מיקום קובץ הדאטה
const dbPath = path.resolve(__dirname, process.env.DB_FILE || 'data.db');
let db;

// התחברות למסד הנתונים ויצירת הטבלה במידת הצורך
function connectToDB() {
  db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error('❌ Failed to connect to SQLite database:', err.message);
      return;
    }
    console.log('✅ Connected to SQLite database at', dbPath);

    // יצירת טבלה עם שדות כולל JSON טקסט
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('student', 'tutor')) NOT NULL,
        phone TEXT,
        username TEXT,
        dob TEXT,
        subjects TEXT,           -- JSON
        profilePhotoName TEXT,
        profilePhotoData TEXT,
        background TEXT,
        bio TEXT,
        pricePerHour REAL,
        teachingMethod TEXT,
        area TEXT,
        availability TEXT,       -- JSON
        lessonSlots TEXT,        -- JSON
        reviews TEXT            -- JSON
      )
    `, (err) => {
      if (err) {
        console.error('❌ Error creating users table:', err.message);
      } else {
        console.log('✅ Users table is ready.');
      }
    });
  });
}

// קריאה לחיבור למסד
connectToDB();

// פונקציות עזר שמחזירות Promise
function runQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function getQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function allQuery(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

// פונקציה לסידור המרה של שדות JSON בקבלת רשומה בודדת
function parseJsonFields(user) {
  if (!user) return null;
  try {
    if (user.subjects) user.subjects = JSON.parse(user.subjects);
  } catch { user.subjects = null; }
  try {
    if (user.availability) user.availability = JSON.parse(user.availability);
  } catch { user.availability = null; }
  try {
    if (user.lessonSlots) user.lessonSlots = JSON.parse(user.lessonSlots);
  } catch { user.lessonSlots = null; }
  try {
    if (user.reviews) user.reviews = JSON.parse(user.reviews);
  } catch { user.reviews = null; }
  return user;
}

// פונקציה להמרת שדות JSON לפני שמירה במסד
function stringifyJsonFields(user) {
  const copy = { ...user };
  if (copy.subjects && typeof copy.subjects !== 'string') copy.subjects = JSON.stringify(copy.subjects);
  if (copy.availability && typeof copy.availability !== 'string') copy.availability = JSON.stringify(copy.availability);
  if (copy.lessonSlots && typeof copy.lessonSlots !== 'string') copy.lessonSlots = JSON.stringify(copy.lessonSlots);
  if (copy.reviews && typeof copy.reviews !== 'string') copy.reviews = JSON.stringify(copy.reviews);
  return copy;
}

// ===== API ===== //

module.exports = {

  // שליפות
  async getAllUsers() {
    const rows = await allQuery('SELECT * FROM users');
    return rows.map(parseJsonFields);
  },

  async getAllTutors() {
    const rows = await allQuery("SELECT * FROM users WHERE role = 'tutor'");
    return rows.map(parseJsonFields);
  },

  async getAllStudents() {
    const rows = await allQuery("SELECT * FROM users WHERE role = 'student'");
    return rows.map(parseJsonFields);
  },

  async getUserByEmail(email) {
    const row = await getQuery('SELECT * FROM users WHERE email = ?', [email]);
    return parseJsonFields(row);
  },

  async getUserById(id) {
    const row = await getQuery('SELECT * FROM users WHERE id = ?', [id]);
    return parseJsonFields(row);
  },

  // פונקציה חדשה שנדרשת: לפי username
  async getUserByUsername(username) {
    const row = await getQuery('SELECT * FROM users WHERE username = ?', [username]);
    return parseJsonFields(row);
  },

  async getUsersByRole(role) {
    const rows = await allQuery("SELECT * FROM users WHERE role = ?", [role]);
    return rows.map(parseJsonFields);
  },

  // יצירה
  async createUser(user) {
    const u = stringifyJsonFields(user);

    return runQuery(
      `INSERT INTO users (
        name, email, password, role, phone, username, dob, subjects, 
        profilePhotoName, profilePhotoData, background, bio, pricePerHour, 
        teachingMethod, area, availability, lessonSlots, reviews
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        u.name,
        u.email,
        u.password,
        u.role,
        u.phone || null,
        u.username || null,
        u.dob || null,
        u.subjects || null,
        u.profilePhotoName || null,
        u.profilePhotoData || null,
        u.background || null,
        u.bio || null,
        u.pricePerHour || null,
        u.teachingMethod || null,
        u.area || null,
        u.availability || null,
        u.lessonSlots || null,
        u.reviews || null
      ]
    );
  },

  // עדכונים
  async updateUserById(id, updates) {
    const u = stringifyJsonFields(updates);
    const fields = Object.keys(u);
    const values = Object.values(u);
    const setClause = fields.map((field) => `${field} = ?`).join(', ');
    return runQuery(`UPDATE users SET ${setClause} WHERE id = ?`, [...values, id]);
  },

  async updateUserByEmail(email, updates) {
    const u = stringifyJsonFields(updates);
    const fields = Object.keys(u);
    const values = Object.values(u);
    const setClause = fields.map((field) => `${field} = ?`).join(', ');
    return runQuery(`UPDATE users SET ${setClause} WHERE email = ?`, [...values, email]);
  },

  // מחיקה
  async deleteUserByEmail(email) {
    return runQuery('DELETE FROM users WHERE email = ?', [email]);
  },

  // חיפוש מורים עם פילטרים
  async searchTutors({ subjects, area, maxPrice }) {
    let sql = `SELECT * FROM users WHERE role = 'tutor'`;
    const params = [];

    if (subjects) {
      sql += ` AND subjects LIKE ?`;
      params.push(`%${subjects}%`);
    }

    if (area) {
      sql += ` AND area LIKE ?`;
      params.push(`%${area}%`);
    }

    if (maxPrice !== null && maxPrice !== undefined) {
      sql += ` AND pricePerHour <= ?`;
      params.push(maxPrice);
    }

    const rows = await allQuery(sql, params);
    return rows.map(parseJsonFields);
  }
};

module.exports.db = db;




