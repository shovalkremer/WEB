const express = require('express');
const router = express.Router();

const userQueries = require('../models/userModel');
const { authenticateToken, authorizeRoles } = require('../middlewares/authMiddleware.js');

// ===== Helper for parsing JSON fields stored as strings =====
function parseField(field) {
  if (!field) return [];
  if (Array.isArray(field)) return field;
  try {
    const parsed = JSON.parse(field);
    if (Array.isArray(parsed)) return parsed;
  } catch (err) {}
  return field.toString().split(',').map(s => s.trim()).filter(Boolean);
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// 🔐 קבלת כל המשתמשים – רק אדמין
router.get('/', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const users = await userQueries.getAllUsersAsync();
    const parsedUsers = users.map(user => ({
      ...user,
      subjects: parseField(user.subjects),
      availability: parseField(user.availability),
      lessonSlots: parseField(user.lessonSlots),
      reviews: parseField(user.reviews),
      password: undefined,
    }));
    res.json(parsedUsers);
  } catch (err) {
    console.error('Error fetching all users:', err);
    res.status(500).json({ error: err.message });
  }
});

// 🔐 קבלת מורים בלבד – למורה או אדמין
router.get('/tutors', authenticateToken, authorizeRoles('tutor', 'admin'), async (req, res) => {
  try {
    const tutors = await userQueries.getUsersByRoleAsync('tutor');
    const parsedTutors = tutors.map(user => ({
      ...user,
      subjects: parseField(user.subjects),
      availability: parseField(user.availability),
      lessonSlots: parseField(user.lessonSlots),
      reviews: parseField(user.reviews),
      password: undefined,
    }));
    res.json(parsedTutors);
  } catch (err) {
    console.error('Error fetching tutors:', err);
    res.status(500).json({ error: err.message });
  }
});

// 🔐 קבלת סטודנטים בלבד – לסטודנט או אדמין
router.get('/students', authenticateToken, authorizeRoles('student', 'admin'), async (req, res) => {
  try {
    const students = await userQueries.getUsersByRoleAsync('student');
    const parsedStudents = students.map(user => ({
      ...user,
      subjects: parseField(user.subjects),
      availability: parseField(user.availability),
      lessonSlots: parseField(user.lessonSlots),
      reviews: parseField(user.reviews),
      password: undefined,
    }));
    res.json(parsedStudents);
  } catch (err) {
    console.error('Error fetching students:', err);
    res.status(500).json({ error: err.message });
  }
});

// 🔍 חיפוש מורים לפי סינון – פתוח לכולם
router.get('/search', async (req, res) => {
  const filters = {
    subjects: req.query.subjects || '',
    area: req.query.area || '',
    maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : null,
  };

  try {
    const tutors = await userQueries.searchTutorsAsync(filters);
    const parsedTutors = tutors.map(user => ({
      ...user,
      subjects: parseField(user.subjects),
      availability: parseField(user.availability),
      lessonSlots: parseField(user.lessonSlots),
      reviews: parseField(user.reviews),
      password: undefined,
    }));
    res.json(parsedTutors);
  } catch (err) {
    console.error('Error searching tutors:', err);
    res.status(500).json({ error: err.message });
  }
});

// ➕ יצירת משתמש חדש
router.post('/', async (req, res) => {
  const user = req.body;

  if (!user.email || !isValidEmail(user.email)) {
    return res.status(400).json({ error: 'Invalid or missing email' });
  }

  try {
    const result = await userQueries.createUserAsync(user);
    res.status(201).json({ id: result.id });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ קבלת משתמש לפי username – רק המשתמש עצמו או אדמין
router.get('/username/:username', authenticateToken, async (req, res) => {
  const username = req.params.username;

  if (req.user.username !== username && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  try {
    const user = await userQueries.getUserByUsernameAsync(username);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.subjects = parseField(user.subjects);
    user.availability = parseField(user.availability);
    user.lessonSlots = parseField(user.lessonSlots);
    user.reviews = parseField(user.reviews);
    delete user.password;

    res.json(user);
  } catch (err) {
    console.error(`Error fetching user by username (${username}):`, err);
    res.status(500).json({ error: err.message });
  }
});

// 🔐 קבלת משתמש לפי אימייל – רק המשתמש עצמו או אדמין
router.get('/:email', authenticateToken, async (req, res) => {
  const email = req.params.email;

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  if (req.user.email !== email && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  try {
    const user = await userQueries.getUserByEmailAsync(email);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.subjects = parseField(user.subjects);
    user.availability = parseField(user.availability);
    user.lessonSlots = parseField(user.lessonSlots);
    user.reviews = parseField(user.reviews);
    delete user.password;

    res.json(user);
  } catch (err) {
    console.error(`Error fetching user by email (${email}):`, err);
    res.status(500).json({ error: err.message });
  }
});

// ✏️ עדכון משתמש לפי אימייל – רק המשתמש עצמו או אדמין
router.put('/:email', authenticateToken, async (req, res) => {
  const email = req.params.email;

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  if (req.user.email !== email && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  try {
    const result = await userQueries.updateUserByEmailAsync(email, req.body);
    res.json(result);
  } catch (err) {
    console.error(`Error updating user by email (${email}):`, err);
    res.status(500).json({ error: err.message });
  }
});

// ❌ מחיקת משתמש לפי אימייל – רק המשתמש עצמו או אדמין
router.delete('/:email', authenticateToken, async (req, res) => {
  const email = req.params.email;

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  if (req.user.email !== email && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  try {
    const result = await userQueries.deleteUserByEmailAsync(email);
    res.json(result);
  } catch (err) {
    console.error(`Error deleting user by email (${email}):`, err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
