const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const router = express.Router();
require('dotenv').config();

const {
  getUserByEmailAsync,
  getUserByUsernameAsync,
  getUsersByRoleAsync,
  createUserAsync,
  updateUserByEmailAsync,
  searchTutorsAsync,
  deleteUserByEmailAsync
} = require('../models/userModel');

const SALT_ROUNDS = 10;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';

// ===== Multer Setup for file upload =====
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: function(req, file, cb) {
    const ext = path.extname(file.originalname);
    // ננסה לשלוף את השם הפרטי מתוך name
    const firstName = req.body.name?.split(' ')[0]?.toLowerCase() || 'user';
    cb(null, `${firstName}${ext}`);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // עד 10MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files are allowed!'));
    }
    cb(null, true);
  }
});


// ===== Validation Helpers =====
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function isValidPhone(phone) {
  return /^0\d{9}$/.test(phone);
}
function isStrongPassword(password) {
  return /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&]).{6,}$/.test(password);
}

// ===== JSON field parsing helper =====
function parseField(field) {
  if (!field) return [];

  if (Array.isArray(field)) {
    return field;
  }

  if (typeof field === 'string') {
    try {
      const parsed = JSON.parse(field);
      if (Array.isArray(parsed)) return parsed;
    } catch (err) {
      // Not a JSON string, fallback to comma-split
      return field.split(',').map(s => s.trim()).filter(Boolean);
    }
  }

  return [];
}


// ===== Middleware to authenticate JWT =====
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Access token missing or invalid.' });
  }

  const token = authHeader.split(' ')[1];
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token.' });
    req.user = user;
    next();
  });
};

// ===== POST /auth/signup =====
router.post('/signup', async (req, res) => {
  const {
    name,
    email,
    password,
    role,
    phone,
    username,
    dob,
    subjects,
    profilePhotoName,
    profilePhotoData,
    background,
    bio,
    pricePerHour,
    teachingMethod,
    area,
    availability,
    lessonSlots,
    reviews
  } = req.body;

  if (!name || !email || !password || !role || !username) {
    return res.status(400).json({ message: 'Missing required fields.' });
  }
  if (name.trim().length < 2) return res.status(400).json({ message: 'Name too short.' });
  if (!isValidEmail(email)) return res.status(400).json({ message: 'Invalid email.' });
  if (!isStrongPassword(password)) return res.status(400).json({ message: 'Weak password.' });
  if (!isValidPhone(phone)) return res.status(400).json({ message: 'Invalid phone.' });
  if (!['student', 'tutor'].includes(role)) return res.status(400).json({ message: 'Invalid role.' });

  try {
    const existingUser = await getUserByEmailAsync(email);
    if (existingUser) return res.status(409).json({ message: 'Email already registered.' });

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const userData = {
      name,
      email,
      password: hashedPassword,
      role,
      phone,
      username,
      dob,
      subjects: JSON.stringify(parseField(subjects)),
      profilePhotoName,
      profilePhotoData,
      background,
      bio,
      pricePerHour,
      teachingMethod,
      area,
      availability: JSON.stringify(parseField(availability)),
      lessonSlots: JSON.stringify(parseField(lessonSlots)),
      reviews: JSON.stringify(parseField(reviews))
    };

    const result = await createUserAsync(userData);

    const token = jwt.sign({ username, role }, JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      message: 'Signup successful',
      token,
      username,
      role
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ===== POST /auth/login =====
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) return res.status(400).json({ message: 'Missing credentials.' });

  try {
    const user = await getUserByEmailAsync(email);
    if (!user) return res.status(401).json({ message: 'Invalid credentials.' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: 'Invalid credentials.' });

    const token = jwt.sign({ username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

    const userWithoutPassword = { ...user };
    delete userWithoutPassword.password;

    res.json({ message: 'Login successful', token, user: userWithoutPassword });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ===== PUT /auth/user/:username =====
router.put('/user/:username', authenticateJWT, async (req, res) => {
  const { username } = req.params;

  if (req.user.username !== username && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Forbidden.' });
  }

  const {
    name,
    phone,
    subjects,
    background,
    bio,
    pricePerHour,
    teachingMethod,
    area,
    availability,
    lessonSlots,
    reviews
  } = req.body;

  const updates = {
    name,
    phone,
    subjects: JSON.stringify(parseField(subjects)),
    background,
    bio,
    pricePerHour,
    teachingMethod,
    area,
    availability: JSON.stringify(parseField(availability)),
    lessonSlots: JSON.stringify(parseField(lessonSlots)),
    reviews: JSON.stringify(parseField(reviews))
  };

  try {
    const result = await updateUserByEmailAsync(req.user.email, updates);
    if (!result || result.changes === 0) return res.status(404).json({ message: 'User not found or no changes made.' });
    res.json({ message: 'Profile updated successfully.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Update failed.' });
  }
});

// ===== DELETE /auth/user/:username =====
router.delete('/user/:username', authenticateJWT, async (req, res) => {
  const { username } = req.params;

  if (req.user.username !== username && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Forbidden.' });
  }

  try {
    const result = await deleteUserByEmailAsync(req.user.email);
    if (!result || result.changes === 0) return res.status(404).json({ message: 'User not found.' });
    res.json({ message: 'User deleted successfully.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Deletion failed.' });
  }
});

// ===== GET /auth/tutors =====
router.get('/tutors', async (req, res) => {
  try {
    const tutors = await getUsersByRoleAsync('tutor');
    const cleanTutors = tutors.map(t => ({
      ...t,
      subjects: parseField(t.subjects),
      availability: parseField(t.availability),
      lessonSlots: parseField(t.lessonSlots),
      reviews: parseField(t.reviews),
      password: undefined,
    }));
    res.json(cleanTutors);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching tutors." });
  }
});

// ===== GET /auth/tutors/:username =====
router.get('/tutors/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const tutor = await getUserByUsernameAsync(username);
    if (!tutor || tutor.role !== 'tutor') return res.status(404).json({ message: "Tutor not found." });

    tutor.subjects = parseField(tutor.subjects);
    tutor.availability = parseField(tutor.availability);
    tutor.lessonSlots = parseField(tutor.lessonSlots);
    tutor.reviews = parseField(tutor.reviews);
    delete tutor.password;

    res.json(tutor);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error retrieving tutor." });
  }
});

// ===== GET /auth/user/:username =====
router.get('/user/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const user = await getUserByUsernameAsync(username);
    if (!user) return res.status(404).json({ message: "User not found." });

    user.subjects = parseField(user.subjects);
    user.availability = parseField(user.availability);
    user.lessonSlots = parseField(user.lessonSlots);
    user.reviews = parseField(user.reviews);
    delete user.password;

    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error retrieving user." });
  }
});

// ===== NEW POST /auth/tutors/signup =====
router.post('/tutors/signup', upload.single('profilePhoto'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Profile photo is required' });
    }

    const {
      name,
      email,
      password,
      phone,
      username,
      dob,
      subjects,
      background,
      bio,
      pricePerHour,
      teachingMethod,
      area,
      availability,
      lessonSlots,
      reviews
    } = req.body;

    if (!name || !email || !password || !username) {
      return res.status(400).json({ message: 'Missing required fields.' });
    }
    if (!isValidEmail(email)) return res.status(400).json({ message: 'Invalid email.' });
    if (!isStrongPassword(password)) return res.status(400).json({ message: 'Weak password.' });
    if (!isValidPhone(phone)) return res.status(400).json({ message: 'Invalid phone.' });

    const existingUser = await getUserByEmailAsync(email);
    if (existingUser) return res.status(409).json({ message: 'Email already registered.' });

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const newUser = {
      name,
      email,
      password: hashedPassword,
      role: 'tutor',
      phone,
      username,
      dob,
      subjects: JSON.stringify(parseField(subjects)),
      profilePhotoName: req.file.filename,
      profilePhotoData: null,
      background,
      bio,
      pricePerHour,
      teachingMethod,
      area,
      availability: JSON.stringify(parseField(availability)),
      lessonSlots: JSON.stringify(parseField(lessonSlots)),
      reviews: JSON.stringify(parseField(reviews))
    };

    await createUserAsync(newUser);

    const token = jwt.sign({ username, role: 'tutor' }, JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      message: 'Tutor registered successfully',
      token,
      username,
      profilePhotoFilename: req.file.filename,
      photoUrl: `/uploads/${req.file.filename}`
    });

  } catch (err) {
    console.error('Error processing tutor signup:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// ===== GET /auth/tutors/search =====
router.get('/tutors/search', async (req, res) => {
  try {
    const filters = {
      subjects: req.query.subjects,
      area: req.query.area,
      maxPrice: req.query.maxPrice,
      teachingMethod: req.query.teachingMethod
    };

    const tutors = await searchTutorsAsync(filters);
    const cleaned = tutors.map(t => ({
      ...t,
      subjects: parseField(t.subjects),
      availability: parseField(t.availability),
      lessonSlots: parseField(t.lessonSlots),
      reviews: parseField(t.reviews),
      password: undefined
    }));

    res.json(cleaned);
  } catch (err) {
    console.error('Error searching tutors:', err);
    res.status(500).json({ error: 'Failed to search tutors.' });
  }
});


module.exports = router;








