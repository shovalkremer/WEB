const userModel = require('../models/userModel.js');

// ✅ Get all users
const getAllUsers = async (req, res) => {
  try {
    const users = await userModel.getAllUsersAsync();
    res.json(users);
  } catch (err) {
    console.error('Error retrieving users:', err);
    res.status(500).json({ error: 'Error retrieving users' });
  }
};

// ✅ Get user by email
const getUserByEmail = async (req, res) => {
  const { email } = req.params;
  try {
    const user = await userModel.getUserByEmailAsync(email);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error(`Error retrieving user by email (${email}):`, err);
    res.status(500).json({ error: 'Error retrieving user' });
  }
};

// ✅ Get user by ID
const getUserById = async (req, res) => {
  const { id } = req.params;
  try {
    const user = await userModel.getUserByIdAsync(id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error(`Error retrieving user by ID (${id}):`, err);
    res.status(500).json({ error: 'Error retrieving user' });
  }
};

// ✅ Create user
const createUser = async (req, res) => {
  const user = req.body;
  try {
    const result = await userModel.createUserAsync(user);
    res.status(201).json({ message: 'User created successfully', id: result.id });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Error creating user' });
  }
};

// ✅ Update user by ID
const updateUser = async (req, res) => {
  const { id } = req.params;
  const user = req.body;
  try {
    const result = await userModel.updateUserAsync(id, user);
    if (!result || result.changes === 0) return res.status(404).json({ error: 'User not found for update' });
    res.json({ message: 'User updated successfully' });
  } catch (err) {
    console.error(`Error updating user by ID (${id}):`, err);
    res.status(500).json({ error: 'Error updating user' });
  }
};

// ✅ Update user by email
const updateUserByEmail = async (req, res) => {
  const { email } = req.params;
  const user = req.body;
  try {
    const result = await userModel.updateUserByEmailAsync(email, user);
    if (!result || result.changes === 0) return res.status(404).json({ error: 'User not found for update' });
    res.json({ message: 'User updated successfully by email' });
  } catch (err) {
    console.error(`Error updating user by email (${email}):`, err);
    res.status(500).json({ error: 'Error updating user by email' });
  }
};

// ✅ Delete user by email
const deleteUserByEmail = async (req, res) => {
  const { email } = req.params;
  try {
    const result = await userModel.deleteUserByEmailAsync(email);
    if (!result || result.deleted === 0) return res.status(404).json({ error: 'User not found for deletion' });
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    console.error(`Error deleting user by email (${email}):`, err);
    res.status(500).json({ error: 'Error deleting user' });
  }
};

// ✅ Get users by role
const getUsersByRole = async (req, res) => {
  const { role } = req.params;
  try {
    const users = await userModel.getUsersByRoleAsync(role);
    res.json(users);
  } catch (err) {
    console.error(`Error retrieving users by role (${role}):`, err);
    res.status(500).json({ error: 'Error retrieving users by role' });
  }
};

// ✅ Search tutors by filters
const searchTutors = async (req, res) => {
  const filters = req.query;
  try {
    const tutors = await userModel.searchTutorsAsync(filters);
    res.json(tutors);
  } catch (err) {
    console.error('Error searching tutors:', err);
    res.status(500).json({ error: 'Error searching tutors' });
  }
};

module.exports = {
  getAllUsers,
  getUserByEmail,
  getUserById,
  createUser,
  updateUser,
  updateUserByEmail,
  deleteUserByEmail,
  getUsersByRole,
  searchTutors,
};
