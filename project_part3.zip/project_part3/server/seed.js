import { pool } from './db.js';
import fs from 'fs';

function addDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

function formatDate(date) {
  return date.toISOString().split('T')[0];
}

function addDaysFormatted(date, days = 1) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

export async function insertDemoUsersIfNeeded() {
  try {
    const [results] = await pool.query('SELECT COUNT(*) as cnt FROM users');
    if (results[0].cnt > 0) {
      console.log('ℹ️ Users already exist, skipping demo insert.');
      return;
    }

    const demoUsers = [
      [
        'Shoval Kremer', 'shoval.k@gmail.com', '123456', 'tutor', '0521112233', 'shovalk', '1998-01-01',
        JSON.stringify(['Math', 'English']),
        'shoval.jpg', fs.readFileSync('./seed_uplode/shoval.jpg', 'base64'),
        'BSc in Engineering, passionate about education.', 'Creative and clear teaching style.',
        100.00, 'online', 'Tel Aviv',
        JSON.stringify(['Sunday 14:00', 'Tuesday 18:00']),
        JSON.stringify([{ date: '2025-07-10', time: '16:00' }]),
        JSON.stringify([])
      ],
      [
        'Noa Glik', 'noa.glik@gmail.com', 'abcdef', 'tutor', '0523334444', 'noaglik', '1996-11-20',
        JSON.stringify(['Science']),
        'noa.jpg', fs.readFileSync('./seed_uplode/noa.jpg', 'base64'),
        'MSc in Biology, experienced in tutoring teens.', 'Explains complex topics in a simple way.',
        120.00, 'in person', 'Haifa',
        JSON.stringify(['Monday 16:00', 'Wednesday 10:00']),
        JSON.stringify([{ date: '2025-07-11', time: '17:00' }]),
        JSON.stringify([])
      ]
    ];

    const sql = `INSERT INTO users (
      name, email, password, role, phone, username, dob, subjects,
      profilePhotoName, profilePhotoData, background, bio,
      pricePerHour, teachingMethod, area, availability,
      lessonSlots, reviews
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    for (const [idx, user] of demoUsers.entries()) {
      await pool.query(sql, user);
      console.log(`✅ Demo user #${idx + 1} inserted!`);
    }
  } catch (err) {
    console.error('❌ Error inserting demo users:', err);
  }
}

export async function insertDemoStudentsIfNeeded() {
  try {
    const [results] = await pool.query("SELECT COUNT(*) as cnt FROM users WHERE role = 'student'");
    if (results[0].cnt > 0) {
      console.log('ℹ️ Students already exist, skipping demo insert.');
      return;
    }

    const demoStudents = [
      ['Tom Shalev', 'tom@gmail.com', '123456', 'student', '0543219876', 'tomshalev', '2002-02-16', JSON.stringify(['Math', 'English']), '', '', '', '', null, '', '', '', '', ''],
      ['Yasmin Cohen', 'yasmin.cohen@gmail.com', 'yasminbest', 'student', '0505678987', 'yasminco', '2001-06-24', JSON.stringify(['Science']), '', '', '', '', null, '', '', '', '', '']
    ];

    const sql = `INSERT INTO users (
      name, email, password, role, phone, username, dob, subjects,
      profilePhotoName, profilePhotoData, background, bio,
      pricePerHour, teachingMethod, area,
      availability, lessonSlots, reviews
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    for (const [idx, student] of demoStudents.entries()) {
      await pool.query(sql, student);
      console.log(`✅ Demo student #${idx + 1} inserted!`);
    }
  } catch (err) {
    console.error('❌ Error inserting demo students:', err);
  }
}

export async function insertDemoAvailabilityIfNeeded() {
  try {
    const [tutors] = await pool.query("SELECT id, name FROM users WHERE role = 'tutor'");
    if (tutors.length === 0) return console.log('ℹ️ No tutors found.');

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
    const types = ['online', 'in person'];

    for (const [idx, tutor] of tutors.entries()) {
      const availability = [
        { day: days[(idx * 2) % days.length], date: formatDate(addDays(new Date(), idx)), time: '16:00:00', type: types[idx % types.length] },
        { day: days[(idx * 2 + 1) % days.length], date: formatDate(addDays(new Date(), idx + 1)), time: '18:00:00', type: types[(idx + 1) % types.length] }
      ];

      await pool.query("UPDATE users SET availability = ? WHERE id = ?", [JSON.stringify(availability), tutor.id]);
      console.log(`✅ Availability set for tutor ${tutor.name}`);
    }
  } catch (err) {
    console.error('❌ Error setting availability:', err);
  }
}

export async function insertDemoBookedLessonsIfNeeded() {
  try {
    const [students] = await pool.query("SELECT id FROM users WHERE role = 'student'");
    const [tutors] = await pool.query("SELECT id, name FROM users WHERE role = 'tutor'");

    if (students.length === 0 || tutors.length === 0) return console.log('ℹ️ No tutors or students found.');

    for (const [tIdx, tutor] of tutors.entries()) {
      for (const [sIdx, student] of students.entries()) {
        const pastLesson = { studentId: student.id, date: addDaysFormatted(new Date(), -7 - sIdx - tIdx), time: '14:00:00', type: 'in person', status: 'completed' };
        const futureLesson = { studentId: student.id, date: addDaysFormatted(new Date(), 2 + sIdx + tIdx), time: '16:00:00', type: 'online', status: 'upcoming' };

        const [results] = await pool.query("SELECT lessonSlots FROM users WHERE id = ?", [tutor.id]);
        let lessons = [];
        if (results[0]?.lessonSlots) {
          try { lessons = JSON.parse(results[0].lessonSlots); } catch { }
        }

        lessons.push(pastLesson, futureLesson);
        await pool.query("UPDATE users SET lessonSlots = ? WHERE id = ?", [JSON.stringify(lessons), tutor.id]);
        console.log(`✅ Lessons updated for tutor ${tutor.id}`);
      }
    }
  } catch (err) {
    console.error('❌ Error inserting demo lessons:', err);
  }
}

export async function insertDemoReviewsIfNeeded() {
  try {
    const [tutors] = await pool.query("SELECT id, lessonSlots, reviews FROM users WHERE role = 'tutor'");

    const demoReviews = [
      "Amazing tutor! Very clear explanations and super patient.",
      "Good experience, helped me understand difficult topics.",
      "Great teacher! Highly recommended.",
      "Very helpful and friendly.",
      "Excellent explanations and support."
    ];
    const demoStars = [5, 4, 5, 5, 4];

    for (const [idx, tutor] of tutors.entries()) {
      const review = {
        studentName: `Student${idx + 1}`,
        stars: demoStars[idx % demoStars.length],
        text: demoReviews[idx % demoReviews.length],
        created_at: new Date()
      };

      let reviews = [];
      try { if (tutor.reviews) reviews = JSON.parse(tutor.reviews); } catch { }
      reviews.push(review);

      await pool.query("UPDATE users SET reviews = ? WHERE id = ?", [JSON.stringify(reviews), tutor.id]);
      console.log(`✅ Review added for tutor ${tutor.id}`);
    }
  } catch (err) {
    console.error('❌ Error inserting reviews:', err);
  }
}














