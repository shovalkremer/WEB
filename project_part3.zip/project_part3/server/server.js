require('dotenv').config(); // טוען משתני סביבה מקובץ .env
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const multer = require('multer');

require('./db'); // חיבור למסד הנתונים

// ייבוא ראוטים
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 3000;

// CORS - אפשרות לשלוט לפי צורך, כרגע פתוח לכולם
app.use(cors());

// הגדרת תיקיית uploads ושמירת קבצים עם multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads')); // ודא שהתיקייה קיימת
  },
  filename: (req, file, cb) => {
    // יוצר שם קובץ ייחודי לפי timestamp + שם מקורי (אפשר לשנות)
    const ext = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, ext);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, baseName + '-' + uniqueSuffix + ext);
  }
});
const upload = multer({ storage });

// סטטי - קבצי צד לקוח (public) ותמונות שהועלו (uploads)
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Middleware ל־body parser, מוגדל ל־10MB כדי לאפשר קבצים גדולים
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(bodyParser.json({ limit: '10mb' }));

// ===== Routes =====
app.use('/auth', authRoutes);
app.use('/users', userRoutes);


// ===== Global Error Handler =====
app.use((err, req, res, next) => {
  console.error('Server error:', err.stack);
  res.status(500).json({ error: 'Internal server error (500)' });
});

// ===== Route Not Found Handler =====
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found (404)' });
});

// ===== Start Server =====
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
