require('dotenv').config(); // טוען משתני סביבה מקובץ .env
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

// חיבור למסד הנתונים
const db = require('./db');

// ייבוא פונקציות ה-SEED
const {
  insertDemoUsersIfNeeded,
  insertDemoAvailabilityIfNeeded,
  insertDemoBookedLessonsIfNeeded
} = require('./seed'); 

// CORS - פתוח לכולם כרגע
app.use(cors());

// הגדרת תיקיית uploads עם multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads')); // ודא שהתיקייה קיימת
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, ext);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, baseName + '-' + uniqueSuffix + ext);
  }
});
const upload = multer({ storage });

// קבצים סטטיים
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Body parser
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(bodyParser.json({ limit: '10mb' }));

// ראוטים
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
app.use('/auth', authRoutes);
app.use('/users', userRoutes);

// Error handler כללי
app.use((err, req, res, next) => {
  console.error('Server error:', err.stack);
  res.status(500).json({ error: 'Internal server error (500)' });
});

// Route not found
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found (404)' });
});

// ===== בדיקת חיבור למסד MySQL והפעלת SEED ===== //
async function startServer() {
  try {
    const connection = await db.pool.getConnection();
    console.log('✅ Connected to MySQL database!');
    connection.release();

    // כאן מפעילים את הדאטה הדמו אם צריך
    await insertDemoUsersIfNeeded();
    await insertDemoAvailabilityIfNeeded();
    await insertDemoBookedLessonsIfNeeded();

    // הרצת השרת
    app.listen(PORT, () => {
      console.log(`🚀 Server is running on http://localhost:${PORT}`);
    });

  } catch (err) {
    console.error('❌ Failed to connect to MySQL:', err.message);
    process.exit(1); // לא להרים שרת אם המסד לא מחובר
  }
}

startServer();
