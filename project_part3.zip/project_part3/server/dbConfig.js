// dbConfig.js
const config = {
  user: 'root', // או שם המשתמש שלך
  password: 'Yaheli7598!',
  server: 'localhost', // אם ה-SQL Server רץ על המחשב שלך
  database: 'my_project', // שם הדאטה בייס שלך
  options: {
    encrypt: false,
    trustServerCertificate: true,
  }
};

module.exports = config;
