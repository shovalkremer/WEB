function authorizeRoles(...allowedRoles) {
  return (req, res, next) => {
    const user = req.user;

    if (!user || !user.role) {
      return res.status(401).json({ message: 'Access denied: user not authenticated or role missing.' });
    }

    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ message: `Access denied: role '${user.role}' is not authorized.` });
    }

    next();
  };
}

module.exports = authorizeRoles;



