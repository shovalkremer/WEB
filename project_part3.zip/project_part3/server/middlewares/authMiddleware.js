
require('dotenv').config();
const jwt = require('jsonwebtoken');
const authorizeRoles = require('../middlewares/roleMiddleware');

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error('Missing JWT_SECRET environment variable');
}

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ message: 'Access denied. Token missing.' });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token.' });
    }

    req.user = decoded; // לדוגמה: { username, role, iat, exp }
    next();
  });
}

module.exports = {
  authenticateToken,
  authorizeRoles,
};


