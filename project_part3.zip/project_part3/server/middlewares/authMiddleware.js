require('dotenv').config();
const jwt = require('jsonwebtoken');
const authorizeRoles = require('../middlewares/roleMiddleware');

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error('Missing JWT_SECRET environment variable');
}

function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Access denied. Token missing or malformed.' });
  }

  const token = authHeader.split(' ')[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token.' });
    }

    // You can add additional checks or limit the fields passed to req.user
    req.user = {
      username: decoded.username,
      email: decoded.email,
      role: decoded.role,
    };

    next();
  });
}

module.exports = {
  authenticateToken,
  authorizeRoles,
};



