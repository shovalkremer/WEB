const { db } = require('../db');


// === פונקציות async/await ===

function getAllUsersAsync() {
  return new Promise((resolve, reject) => {
    db.all("SELECT * FROM users", [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function getUserByEmailAsync(email) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE email = ?", [email], (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function getUserByIdAsync(id) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE id = ?", [id], (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function createUserAsync(user) {
  return new Promise((resolve, reject) => {
    const sql = `
      INSERT INTO users 
      (name, email, password, role, phone, username, dob, subjects, profilePhotoName, profilePhotoData, background, bio, pricePerHour, teachingMethod, area, availability, lessonSlots, reviews)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
      user.name || '',
      user.email || '',
      user.password || '',
      user.role || 'student',
      user.phone || '',
      user.username || '',
      user.dob || '',
      JSON.stringify(user.subjects || []),
      user.profilePhotoName || null,
      user.profilePhotoData || null,
      user.background || '',
      user.bio || '',
      user.pricePerHour || null,
      user.teachingMethod || '',
      user.area || '',
      JSON.stringify(user.availability || []),
      JSON.stringify(user.lessonSlots || []),
      JSON.stringify(user.reviews || [])
    ];

    db.run(sql, values, function (err) {
      if (err) return reject(err);
      resolve({ id: this.lastID });
    });
  });
}

function updateUserAsync(id, user) {
  return new Promise((resolve, reject) => {
    const sql = `
      UPDATE users SET 
        name = ?, email = ?, password = ?, role = ?, phone = ?, username = ?, dob = ?, subjects = ?, 
        profilePhotoName = ?, profilePhotoData = ?, background = ?, bio = ?, 
        pricePerHour = ?, teachingMethod = ?, area = ?, availability = ?, 
        lessonSlots = ?, reviews = ?
      WHERE id = ?
    `;
    const values = [
      user.name || '',
      user.email || '',
      user.password || '',
      user.role || 'student',
      user.phone || '',
      user.username || '',
      user.dob || '',
      JSON.stringify(user.subjects || []),
      user.profilePhotoName || null,
      user.profilePhotoData || null,
      user.background || '',
      user.bio || '',
      user.pricePerHour || null,
      user.teachingMethod || '',
      user.area || '',
      JSON.stringify(user.availability || []),
      JSON.stringify(user.lessonSlots || []),
      JSON.stringify(user.reviews || []),
      id
    ];

    db.run(sql, values, function (err) {
      if (err) return reject(err);
      resolve({ changes: this.changes });
    });
  });
}

function updateUserByEmailAsync(email, user) {
  return new Promise((resolve, reject) => {
    const sql = `
      UPDATE users SET 
        name = ?, password = ?, phone = ?, username = ?, dob = ?, subjects = ?, 
        profilePhotoName = ?, profilePhotoData = ?, background = ?, bio = ?, 
        pricePerHour = ?, teachingMethod = ?, area = ?, availability = ?, 
        lessonSlots = ?, reviews = ?
      WHERE email = ?
    `;
    const values = [
      user.name || '',
      user.password || '',
      user.phone || '',
      user.username || '',
      user.dob || '',
      JSON.stringify(user.subjects || []),
      user.profilePhotoName || null,
      user.profilePhotoData || null,
      user.background || '',
      user.bio || '',
      user.pricePerHour || null,
      user.teachingMethod || '',
      user.area || '',
      JSON.stringify(user.availability || []),
      JSON.stringify(user.lessonSlots || []),
      JSON.stringify(user.reviews || []),
      email
    ];

    db.run(sql, values, function (err) {
      if (err) return reject(err);
      resolve({ changes: this.changes });
    });
  });
}

function deleteUserByEmailAsync(email) {
  return new Promise((resolve, reject) => {
    db.run("DELETE FROM users WHERE email = ?", [email], function (err) {
      if (err) return reject(err);
      resolve({ deleted: this.changes });
    });
  });
}

function getUsersByRoleAsync(role) {
  return new Promise((resolve, reject) => {
    db.all("SELECT * FROM users WHERE role = ?", [role], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function searchTutorsAsync(filters) {
  return new Promise((resolve, reject) => {
    let sql = "SELECT * FROM users WHERE role = 'tutor'";
    const params = [];

    if (filters.subjects) {
      sql += " AND subjects LIKE ?";
      params.push(`%${filters.subjects}%`);
    }

    if (filters.area) {
      sql += " AND area LIKE ?";
      params.push(`%${filters.area}%`);
    }

    if (filters.maxPrice) {
      sql += " AND pricePerHour <= ?";
      params.push(filters.maxPrice);
    }

    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function getUserByUsernameAsync(username) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

module.exports = {
  getAllUsersAsync,
  getUserByEmailAsync,
  getUserByIdAsync,
  createUserAsync,
  updateUserAsync,
  updateUserByEmailAsync,
  deleteUserByEmailAsync,
  getUsersByRoleAsync,
  searchTutorsAsync,
  getUserByUsernameAsync
};

