const { pool } = require('../db');

// עוזר להמיר שדות JSON למחרוזת לפני הכנסת נתונים
function stringifyJsonFields(user) {
  return {
    ...user,
    subjects: JSON.stringify(user.subjects || []),
    availability: JSON.stringify(user.availability || []),
    lessonSlots: JSON.stringify(user.lessonSlots || []),
    reviews: JSON.stringify(user.reviews || []),
  };
}

// עוזר להמיר שדות JSON בחזרה לאובייקטים כשמקבלים מה-DB
function parseJsonFields(user) {
  if (!user) return null;
  try { user.subjects = JSON.parse(user.subjects); } catch {}
  try { user.availability = JSON.parse(user.availability); } catch {}
  try { user.lessonSlots = JSON.parse(user.lessonSlots); } catch {}
  try { user.reviews = JSON.parse(user.reviews); } catch {}
  return user;
}

async function getAllUsersAsync() {
  const [rows] = await pool.query("SELECT * FROM users");
  return rows.map(parseJsonFields);
}

async function getUserByEmailAsync(email) {
  const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
  return parseJsonFields(rows[0]);
}

async function getUserByIdAsync(id) {
  const [rows] = await pool.query("SELECT * FROM users WHERE id = ?", [id]);
  return parseJsonFields(rows[0]);
}

async function getUserByUsernameAsync(username) {
  const [rows] = await pool.query("SELECT * FROM users WHERE username = ?", [username]);
  return parseJsonFields(rows[0]);
}

async function createUserAsync(user) {
  const u = stringifyJsonFields(user);
  const sql = `
    INSERT INTO users (
      name, email, password, role, phone, username, dob, subjects,
      profilePhotoName, profilePhotoData, background, bio, pricePerHour,
      teachingMethod, area, availability, lessonSlots, reviews
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  const values = [
    u.name, u.email, u.password, u.role, u.phone, u.username, u.dob,
    u.subjects, u.profilePhotoName, u.profilePhotoData, u.background, u.bio,
    u.pricePerHour, u.teachingMethod, u.area, u.availability, u.lessonSlots, u.reviews
  ];

  const [result] = await pool.query(sql, values);
  return { id: result.insertId };
}

async function updateUserAsync(id, user) {
  const u = stringifyJsonFields(user);
  const sql = `
    UPDATE users SET 
      name = ?, email = ?, password = ?, role = ?, phone = ?, username = ?, dob = ?, subjects = ?, 
      profilePhotoName = ?, profilePhotoData = ?, background = ?, bio = ?, 
      pricePerHour = ?, teachingMethod = ?, area = ?, availability = ?, 
      lessonSlots = ?, reviews = ?
    WHERE id = ?
  `;
  const values = [
    u.name, u.email, u.password, u.role, u.phone, u.username, u.dob, u.subjects,
    u.profilePhotoName, u.profilePhotoData, u.background, u.bio,
    u.pricePerHour, u.teachingMethod, u.area, u.availability, u.lessonSlots, u.reviews,
    id
  ];

  const [result] = await pool.query(sql, values);
  return { changes: result.affectedRows };
}

async function updateUserByEmailAsync(email, user) {
  const u = stringifyJsonFields(user);
  const sql = `
    UPDATE users SET 
      name = ?, password = ?, phone = ?, username = ?, dob = ?, subjects = ?, 
      profilePhotoName = ?, profilePhotoData = ?, background = ?, bio = ?, 
      pricePerHour = ?, teachingMethod = ?, area = ?, availability = ?, 
      lessonSlots = ?, reviews = ?
    WHERE email = ?
  `;
  const values = [
    u.name, u.password, u.phone, u.username, u.dob, u.subjects,
    u.profilePhotoName, u.profilePhotoData, u.background, u.bio,
    u.pricePerHour, u.teachingMethod, u.area, u.availability, u.lessonSlots, u.reviews,
    email
  ];

  const [result] = await pool.query(sql, values);
  return { changes: result.affectedRows };
}

async function deleteUserByEmailAsync(email) {
  const [result] = await pool.query("DELETE FROM users WHERE email = ?", [email]);
  return { deleted: result.affectedRows };
}

async function getUsersByRoleAsync(role) {
  const [rows] = await pool.query("SELECT * FROM users WHERE role = ?", [role]);
  return rows.map(parseJsonFields);
}

async function searchTutorsAsync(filters) {
  let sql = "SELECT * FROM users WHERE role = 'tutor'";
  const params = [];

  if (filters.subjects && typeof filters.subjects === "string" && filters.subjects.trim() !== "") {
    sql += " AND subjects LIKE ?";
    params.push(`%${filters.subjects}%`);
  }

  if (filters.area && typeof filters.area === "string" && filters.area.trim() !== "") {
    sql += " AND area LIKE ?";
    params.push(`%${filters.area}%`);
  }

  if (filters.maxPrice && !isNaN(filters.maxPrice)) {
    sql += " AND pricePerHour <= ?";
    params.push(Number(filters.maxPrice));
  }

  if (filters.teachingMethod && typeof filters.teachingMethod === "string" && filters.teachingMethod.trim() !== "") {
    sql += " AND teachingMethod LIKE ?";
    params.push(`%${filters.teachingMethod}%`);
  }

  const [rows] = await pool.query(sql, params);
  return rows.map(parseJsonFields);
}

module.exports = {
  getAllUsersAsync,
  getUserByEmailAsync,
  getUserByIdAsync,
  getUserByUsernameAsync,
  createUserAsync,
  updateUserAsync,
  updateUserByEmailAsync,
  deleteUserByEmailAsync,
  getUsersByRoleAsync,
  searchTutorsAsync,
};

