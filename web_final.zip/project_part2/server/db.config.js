// This file stores the database connection settings
export const dbConfig = {
  HOST: 'localhost',         
  USER: 'root',              
  PASSWORD: 'A361722123a',              
  DB: 'my_project',          
};
