document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("tutorSignupForm");
  const successMessage = document.getElementById("successMessage");
  const errorMessage = document.getElementById("error-message");

  form.addEventListener("submit", function (e) {
    // Extract values
    const email = form.email?.value.trim() || "";
    const phone = form.phone?.value.trim() || "";
    const username = form.username?.value.trim() || "";
    const password = form.password?.value.trim() || "";
    const price = form.price?.value.trim() || "";
    const subjects = [...form.querySelectorAll('input[name="subjects[]"]:checked')];
    const profilePhoto = form.profilePhoto?.files[0];

    // === Validations ===
    if (!validateEmail(email)) return blockSubmit(e, "Invalid email address.");
    if (!validatePhone(phone)) return blockSubmit(e, "Invalid phone number.");
    if (username.length < 3) return blockSubmit(e, "Username must be at least 3 characters.");
    if (password.length < 6) return blockSubmit(e, "Password must be at least 6 characters.");
    if (subjects.length === 0) return blockSubmit(e, "Please select at least one subject.");
    if (isNaN(price) || Number(price) <= 0) return blockSubmit(e, "Price must be a positive number.");
    if (!profilePhoto || profilePhoto.size === 0) return blockSubmit(e, "Please upload a profile photo.");

    // If all validations pass – form submits normally through action="/register-tutor"
  });

  function blockSubmit(e, message) {
    e.preventDefault(); // Stop submission
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
    successMessage.style.display = "none";
  }



  function validatePhone(phone) {
    const re = /^(\+972|0)?[2-9]\d{7,8}$/;
    return re.test(phone);
  }

  function validateImageType(type) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    return allowedTypes.includes(type);
  }

});
