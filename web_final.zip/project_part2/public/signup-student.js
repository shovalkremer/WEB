// Import the database connection
import db from '../db.js';

/**
 * Controller: Handles student registration
 * Route: POST /register-student
 */
export const registerStudent = (req, res) => {
  console.log("Received POST /register-student");

  // Destructure standard fields
  const {
    firstName,
    lastName,
    email,
    phone,
    username,
    password,
    dob,
    userType
  } = req.body;

  // Log full incoming request for debugging
  console.log("Request body:", req.body);

    // Validate required fields presence and format
  if (
    !firstName || !lastName || !email ||
    !phone || !username || !password
  ) {
    return res.status(400).send("All required fields must be filled.");
  }

  // Basic email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).send("Invalid email format.");
  }

  // Basic phone validation: starts with 0 and 10 digits total
  const phoneRegex = /^0\d{9}$/;
  if (!phoneRegex.test(phone)) {
    return res.status(400).send("Phone number must start with 0 and contain exactly 10 digits.");
  }

  // Password minimum length
  if (password.length < 6) {
    return res.status(400).send("Password must be at least 6 characters long.");
  }

  // Date of birth validation (optional) - if given, must be valid date and user must be >= 18
  if (dob) {
    const birthDate = new Date(dob);
    if (isNaN(birthDate.getTime())) {
      return res.status(400).send("Invalid date of birth.");
    }
  }

  // Handle subjects[] - can arrive as string or array
  let subjectsArray = req.body["subjects[]"];

  // If nothing selected, treat as empty array
  if (!subjectsArray) {
    subjectsArray = [];
  }

  // If one subject selected, convert to array
  if (!Array.isArray(subjectsArray)) {
    subjectsArray = [subjectsArray];
  }

  // Convert to JSON string for DB
  const subjects = JSON.stringify(subjectsArray);

  // Check for existing student
  const checkQuery = `
    SELECT * FROM students
    WHERE email = ? OR phone = ? OR username = ?
  `;

  db.query(checkQuery, [email, phone, username], (err, existing) => {
    if (err) {
      console.error("Error checking existing student:", err);
      return res.status(500).send("Internal server error.");
    }

    if (existing.length > 0) {
      return res.status(400).send("A student with this email, phone or username already exists.");
    }

    // Insert new student
    const insertQuery = `
      INSERT INTO students (
        firstName, lastName, email, phone,
        username, password, dob, userType, subjects
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      firstName,
      lastName,
      email,
      phone,
      username,
      password,
      dob || null,
      userType,
      subjects
    ];

    db.query(insertQuery, values, (err, result) => {
      if (err) {
        console.error("Failed to insert student:", err);
        return res.status(500).send("Failed to register student.");
      }

      console.log("Student registered successfully.");
      res.redirect('/login.html');
    });
  });
};
