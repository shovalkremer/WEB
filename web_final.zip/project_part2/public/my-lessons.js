document.addEventListener("DOMContentLoaded", () => {
  fetch("/my-lessons")
    .then((res) => res.json())
    .then((lessons) => {
      const upcomingContainer = document.getElementById("upcoming-lessons");
      const pastContainer = document.getElementById("past-lessons");

      let authUser = {};
      try {
        const rawCookie = document.cookie
          .split("; ")
          .find(row => row.startsWith("authUser="))
          ?.split("=")[1];
        if (rawCookie) {
          authUser = JSON.parse(decodeURIComponent(rawCookie));
        }
      } catch (err) {
        console.warn("Could not parse authUser cookie:", err);
      }

      const now = new Date();

      lessons.forEach(lesson => {
        // parse date and time into a local Date object
        const lessonDateTime = new Date(lesson.date); 
        const [hour, minute, second] = lesson.time.split(":").map(Number);

        const localLessonTime = new Date(
        lessonDateTime.getFullYear(),
        lessonDateTime.getMonth(),
        lessonDateTime.getDate(),
        hour,
        minute,
        second
        );

        const isPast = localLessonTime < now;

        const formattedDate = localLessonTime.toLocaleDateString("en-GB", {
          day: '2-digit',
          month: 'short',
          year: 'numeric'
        });

        const formattedTime = lesson.time?.slice(0, 5) || '';

        const div = document.createElement("div");
        div.className = "lesson-card";
        div.innerHTML = `
          <p><strong>${lesson.type}</strong> lesson with <strong>${lesson.withName}</strong></p>
          <p>📅 ${formattedDate} &nbsp;&nbsp;&nbsp; 🕒 ${formattedTime}</p>
        `;

        if (isPast && authUser?.userType === "student") {
          const btn = document.createElement("button");
          btn.textContent = "Leave Review";
          btn.className = "review-btn";
          btn.dataset.lessonId = lesson.id;
          btn.addEventListener("click", () => openReviewModal(lesson.id));
          div.appendChild(btn);
        }

        if (isPast) {
          pastContainer.appendChild(div);
        } else {
          upcomingContainer.appendChild(div);
        }
      });
    })
    .catch(err => {
      console.error("Failed to load lessons:", err);
    });
});

// Review Modal logic
function openReviewModal(lessonId) {
  document.getElementById("lessonId").value = lessonId;
  document.getElementById("reviewModal").style.display = "block";
}

document.getElementById("closeModal").addEventListener("click", () => {
  document.getElementById("reviewModal").style.display = "none";
});

document.getElementById("reviewForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const lessonId = document.getElementById("lessonId").value;
  const stars = document.getElementById("stars").value;
  const text = document.getElementById("text").value;

  const res = await fetch("/submit-review", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ lessonId, stars, text }),
  });

  if (res.ok) {
    alert("Review submitted!");
    document.getElementById("reviewModal").style.display = "none";
  } else {
    alert("Failed to submit review");
  }
});
