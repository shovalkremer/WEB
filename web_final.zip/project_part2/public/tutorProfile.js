document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const username = params.get("username");

  if (!username) {
    document.querySelector(".tutor-profile").innerHTML = "<h2>Teacher not found</h2>";
    return;
  }

  fetch(`/get-tutor/${username}`)
    .then((res) => {
      if (!res.ok) {
        throw new Error("Tutor not found");
      }
      return res.json();
    })
    .then((tutor) => {
      // Image
      if (tutor.profilePhoto && tutor.profilePhoto.data) {
        const byteArray = new Uint8Array(tutor.profilePhoto.data);
        const base64String = btoa(
          byteArray.reduce((data, byte) => data + String.fromCharCode(byte), '')
        );
        document.getElementById("tutorImage").src = `data:image/jpeg;base64,${base64String}`;
      } else {
        document.getElementById("tutorImage").src = "images/default.png";
      }

      // Basic info
      document.getElementById("tutorName").textContent = `${tutor.firstName} ${tutor.lastName}`;
      let subjects = [];
        try {
          subjects = Array.isArray(tutor.subjects) ? tutor.subjects : JSON.parse(tutor.subjects || "[]");
        } catch {
          subjects = [];
      }
      document.getElementById("tutorSubject").textContent = subjects.join(", ") || "Not specified";
      document.getElementById("tutorRate").textContent = tutor.rates || "Not specified";
      document.getElementById("tutorFormat").textContent = tutor.teachingMethod || "Not specified";
      document.getElementById("tutorLocation").textContent = tutor.area || "Not specified";
      document.getElementById("tutorBio").textContent = tutor.bio || "Not specified";
      document.getElementById("tutorExperience").textContent = tutor.background || "Not specified";
      document.getElementById("tutorPhone").textContent = tutor.phone || "Not specified";

      //  Load availability for this tutor
      fetch(`/availability/${username}`)
        .then((res) => res.json())
        .then((slots) => {
          const lessonSlotsDiv = document.getElementById("lessonSlots");
          lessonSlotsDiv.innerHTML = "";

          if (!slots || slots.length === 0) {
            lessonSlotsDiv.innerHTML = "<p>No lessons available</p>";
            return;
          }

          slots.forEach((slot) => {
            const dateStr = new Date(slot.date).toLocaleDateString("en-GB");
            const slotDiv = document.createElement("div");
            const timeStr = slot.time.slice(0, 5); // Removes :00
            console.log("Raw slot sent to button:", slot);
            slotDiv.className = "lesson-slot";
            slotDiv.innerHTML = `
              <span class="slot-date"> ${slot.day} (${dateStr} at ${timeStr})</span>
              <span class="slot-type"> ${slot.type}</span>
              <span class="slot-price">₪${tutor.rates}</span>
              <button class="book-btn" data-date="${slot.date}" data-time="${slot.time}" data-type="${slot.type}">
                  Book Lesson
                </button>

            `;
            lessonSlotsDiv.appendChild(slotDiv);
          });
        })
        .catch((err) => {
          console.error("Error loading availability:", err);
          document.getElementById("lessonSlots").innerHTML = "<p>Could not load lesson slots</p>";
        });


    const reviewsDiv = document.getElementById("tutorReviews");
    reviewsDiv.innerHTML = "";

    if (tutor.reviews && Array.isArray(tutor.reviews) && tutor.reviews.length > 0) {
      tutor.reviews.forEach(review => {
      const rating = Number(review.stars) || 0;
      const stars = "★".repeat(rating) + "☆".repeat(5 - rating);

      const formattedDate = new Date(review.date).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      });

      const reviewDiv = document.createElement("div");
      reviewDiv.className = "review-card";
      reviewDiv.innerHTML = `
        <div class="review-header">
          <span class="review-stars">${stars}</span>
          <span class="review-meta">${review.name || "Anonymous"}, ${formattedDate}</span>
        </div>
        <p class="review-text">"${review.text}"</p>
      `;
      reviewsDiv.appendChild(reviewDiv);
    });

    } else {
      reviewsDiv.innerHTML = "<p>No reviews yet</p>";
    }

    })
    .catch((error) => {
      console.error("Error loading tutor:", error);
      document.querySelector(".tutor-profile").innerHTML = "<h2>Teacher not found</h2>";
    });
});


document.addEventListener("click", (e) => {
  if (e.target.classList.contains("book-btn")) {
    const fullDateTime = e.target.getAttribute("data-date");
    let time = e.target.getAttribute("data-time");
    if (time.length === 5) time += ":00";
    const type = e.target.getAttribute("data-type");

    const localDate = new Date(fullDateTime);
    const date = localDate.getFullYear() + '-' +
             String(localDate.getMonth() + 1).padStart(2, '0') + '-' +
             String(localDate.getDate()).padStart(2, '0');
    const params = new URLSearchParams(window.location.search);
    const tutorUsername = params.get("username");
    console.log("Booking:", { tutorUsername, date, time, type });


    fetch("/book-lesson", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tutorUsername, date, time, type }),
  })
    .then((res) => {
      if (!res.ok) return res.text().then((msg) => { throw new Error(msg); });
      return res.text();
    })
    .then((msg) => {
      alert("Lesson booked successfully!");
      e.target.disabled = true;
      e.target.textContent = "Booked";
      const slotDiv = e.target.closest(".lesson-slot");
      if (slotDiv) slotDiv.remove();
    })
    .catch((err) => {
      console.error(err);
      alert(err.message);
    });

  }
});
