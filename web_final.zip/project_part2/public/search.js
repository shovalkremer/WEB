document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("searchForm");
  const resultsContainer = document.getElementById("resultsContainer");
  const resultsSection = document.getElementById("resultsSection");
  const noResultsMessage = document.getElementById("noResultsMessage");

  /**
   * Validates the form before submitting
   */
  form.addEventListener("submit", (e) => {
    const subject = document.getElementById("subject").value.trim();
    const location = document.getElementById("location").value.trim();
    const price = document.getElementById("price").value.trim();

    const englishPattern = /^[a-zA-Z\s]*$/;

    if (!subject && !location && !price &&!lessonType) {
      alert("Please fill at least one field to perform a search.");
      e.preventDefault();
      return;
    }

    if (price && (isNaN(price) || Number(price) < 0)) {
      alert("Price must be a positive number.");
      e.preventDefault();
      return;
    }

    if (subject && !englishPattern.test(subject)) {
      alert("Subject must be written in English letters only.");
      e.preventDefault();
      return;
    }

    if (location && !englishPattern.test(location)) {
      alert("Location must be written in English letters only.");
      e.preventDefault();
      return;
    }

  });

  /**
   * Fetch tutors from the server using current query parameters
   */
  const fetchTutors = () => {
    const queryParams = window.location.search;

    if (!queryParams) return;

    fetch(`/search${queryParams}`)
      .then((res) => res.json())
      .then((tutors) => {
        displayTutors(tutors);
      })
      .catch((err) => {
        console.error("Error fetching tutors:", err);
        noResultsMessage.textContent = "Oops! No tutors matched your search – we're sorry.";
        noResultsMessage.style.display = "block";
        resultsSection.style.display = "block";
      });
  };

  /**
   * Display the list of tutors dynamically
   */
  const displayTutors = (tutors) => {
    console.log("Tutors array from server:", tutors);

    resultsContainer.innerHTML = "";

    if (!tutors || tutors.length === 0) {
      noResultsMessage.style.display = "block";
      resultsSection.style.display = "block";
      return;
    }

    noResultsMessage.style.display = "none";
    resultsSection.style.display = "block";

    tutors.forEach((tutor) => {
      const card = document.createElement("div");
      card.className = "tutor-card";
        console.log("🧠 profilePhoto for", tutor.username, "→", tutor.profilePhoto);


      let subjects = [];
      try {
        subjects = Array.isArray(tutor.subjects)
          ? tutor.subjects
          : JSON.parse(tutor.subjects || "[]");
      } catch {
        subjects = [];
      }


      let photo = 'https://via.placeholder.com/150'; // fallback

      try {
        const dataArray = tutor?.profilePhoto?.data;

        if (
          Array.isArray(dataArray) &&
          dataArray.length > 10 &&
          typeof dataArray[0] === "number"
        ) {
          const byteArray = new Uint8Array(dataArray);
          const base64String = btoa(
            byteArray.reduce((data, byte) => data + String.fromCharCode(byte), '')
          );

          photo = `data:image/jpeg;base64,${base64String}`;
        } else {
          console.warn(`⚠️ Skipping image for ${tutor.username} – invalid data format`);
        }
      } catch (err) {
        console.warn(`⚠️ Failed to process image for ${tutor.username}:`, err);
      }

      card.innerHTML = `
        <img src="${photo}" alt="Tutor Photo" />
        <h3>${tutor.firstName} ${tutor.lastName}</h3>
        <p><strong>Subjects:</strong> ${subjects.join(', ')}</p>
        <p><strong>Location:</strong> ${tutor.area}</p>
        <p><strong>Method:</strong> ${tutor.teachingMethod}</p>
        <p><strong>Price:</strong> ₪${tutor.rates}</p>
        <button class="btn" onclick="location.href='teacher-profile.html?username=${tutor.username}'">View Profile</button>
      `;

      resultsContainer.appendChild(card);
    });
  };

  // Fetch tutors on page load if there are query parameters
  fetchTutors();
});
