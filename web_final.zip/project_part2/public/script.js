document.addEventListener("DOMContentLoaded", () => {
  // Hamburger menu toggle
  const hamburger = document.getElementById("hamburger");
  const nav = document.querySelector(".main-nav");

  if (hamburger && nav) {
    hamburger.addEventListener("click", () => {
      nav.classList.toggle("open");
      console.log("🍔 Hamburger toggled");
    });
  }

  // Helper function to get cookie by name
  function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(";").shift();
    return null;
  }

  // Get and parse authUser cookie
  const authUserCookie = getCookie("authUser");
  let currentUser = null;

  if (authUserCookie) {
    try {
      currentUser = JSON.parse(decodeURIComponent(authUserCookie));
      console.log("📦 document.cookie =", document.cookie);
      console.log("🍪 authUserCookie =", authUserCookie);
      console.log("👤 currentUser =", currentUser);
    } catch (e) {
      console.error("❌ Failed to parse authUser cookie", e);
    }
  }

  // Access menu elements
  const loginLink = document.getElementById("login-link");
  const profileLink = document.getElementById("profile-link");
  const logoutBtn = document.getElementById("logoutBtn");
  const welcomeText = document.getElementById("welcome-text");

  // Adjust menu based on login state
  if (currentUser) {
    if (loginLink) loginLink.style.display = "none";

    if (profileLink) {
      profileLink.style.display = "inline-block";
      profileLink.textContent = "My Profile";
      profileLink.href = "/profile";
    }

    if (welcomeText) {
      welcomeText.textContent = `Welcome, ${currentUser.email}`;
      welcomeText.style.display = "inline-block";
    }

    if (logoutBtn) {
      logoutBtn.style.display = "inline-block";
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault();
        document.cookie =
          "authUser=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        window.location.href = "login.html";
      });
    }
  } else {
    if (loginLink) loginLink.style.display = "inline-block";
    if (profileLink) profileLink.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "none";
  }

  const findTutorBtn = document.getElementById("find-tutor-btn");

  if (findTutorBtn && currentUser) {
    if (currentUser.userType === "tutor") {
      findTutorBtn.style.display = "none";
    } else {
      findTutorBtn.style.display = "inline-block";
    }
  }

  if (!currentUser && findTutorBtn) {
  findTutorBtn.style.display = "none";
}

const availabilityBtn = document.getElementById("availability-btn");

if (availabilityBtn && currentUser && currentUser.userType === "tutor") {
  availabilityBtn.style.display = "inline-block";
}

const homeLink = document.getElementById("home-link");

if (homeLink) {
  if (currentUser) {
    homeLink.href = "dashboard.html";
  } else {
    homeLink.href = "home.html";
  }
}



});
